"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Calendar, Edit, Trophy, User } from "lucide-react"

// Mock user data
const userData = {
  name: "Rajesh Singh",
  whatsappNumber: "9876543210",
  dateOfBirth: "1985-05-15",
  city: "Dehradun",
  shirtSize: "L",
  shortSize: "M",
  foodPreference: "Vegetarian",
  stayRequired: "Yes",
  events: [
    {
      id: "A",
      name: "Category A (Open)",
      partner: "Amit Kumar",
      partnerStatus: "confirmed",
    },
    {
      id: "C",
      name: "Category C (105+ combined)",
      partner: "Pending",
      partnerStatus: "pending",
    },
  ],
  paymentStatus: "Pending",
  paymentAmount: 6000,
}

export default function UserDashboardPage() {
  const [activeTab, setActiveTab] = useState("profile")

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mx-auto max-w-4xl">
        <div className="mb-8 flex items-center justify-between">
          <Link href="/" className="flex items-center text-[#0F766E] hover:underline">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>
          <Button variant="outline" className="text-red-600 hover:bg-red-50 hover:text-red-700">
            Logout
          </Button>
        </div>

        <div className="mb-8">
          <h1 className="text-3xl font-bold text-[#0F766E]">Welcome, {userData.name}</h1>
          <p className="text-gray-600">Manage your tournament registration details</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="profile" className="flex items-center space-x-2">
              <User className="h-4 w-4" />
              <span>Profile</span>
            </TabsTrigger>
            <TabsTrigger value="events" className="flex items-center space-x-2">
              <Trophy className="h-4 w-4" />
              <span>Events</span>
            </TabsTrigger>
            <TabsTrigger value="schedule" className="flex items-center space-x-2">
              <Calendar className="h-4 w-4" />
              <span>Schedule</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Personal Information</span>
                  <Button variant="outline" size="sm" className="flex items-center space-x-1">
                    <Edit className="h-4 w-4" />
                    <span>Edit</span>
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Full Name</h3>
                    <p>{userData.name}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">WhatsApp Number</h3>
                    <p>{userData.whatsappNumber}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Date of Birth</h3>
                    <p>{new Date(userData.dateOfBirth).toLocaleDateString()}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">City</h3>
                    <p>{userData.city}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Kit & Accommodation</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">T-Shirt Size</h3>
                    <p>{userData.shirtSize}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Shorts Size</h3>
                    <p>{userData.shortSize}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Food Preference</h3>
                    <p>{userData.foodPreference}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Accommodation</h3>
                    <p>{userData.stayRequired === "Yes" ? "Required" : "Not Required"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Payment Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="rounded-md bg-gray-50 p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Registration Fee</h3>
                      <p className="text-sm text-gray-500">Two events with accommodation</p>
                    </div>
                    <p className="text-xl font-bold">₹{userData.paymentAmount}</p>
                  </div>
                  <div className="mt-4 flex items-center justify-between">
                    <h3 className="font-medium">Status</h3>
                    <Badge
                      variant={userData.paymentStatus === "Paid" ? "success" : "outline"}
                      className={
                        userData.paymentStatus === "Paid"
                          ? "bg-green-100 text-green-800"
                          : "bg-yellow-100 text-yellow-800"
                      }
                    >
                      {userData.paymentStatus}
                    </Badge>
                  </div>
                </div>
                {userData.paymentStatus === "Pending" && (
                  <div className="mt-4">
                    <Button className="w-full bg-[#0F766E] hover:bg-[#0c5954]">Make Payment</Button>
                    <p className="mt-2 text-center text-sm text-gray-500">Last date for payment is December 7th</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="events" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Registered Events</CardTitle>
                <CardDescription>You are registered for {userData.events.length} events</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {userData.events.map((event, index) => (
                    <div key={index} className="rounded-md border p-4">
                      <div className="flex items-center justify-between">
                        <h3 className="text-lg font-medium">{event.name}</h3>
                        <Badge
                          variant={event.partnerStatus === "confirmed" ? "default" : "outline"}
                          className={
                            event.partnerStatus === "confirmed"
                              ? "bg-green-100 text-green-800"
                              : "bg-yellow-100 text-yellow-800"
                          }
                        >
                          {event.partnerStatus === "confirmed" ? "Partner Confirmed" : "Partner Pending"}
                        </Badge>
                      </div>
                      <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Your Partner</h4>
                          <p>{event.partner}</p>
                        </div>
                        {event.partnerStatus === "pending" && (
                          <div className="flex items-end justify-end">
                            <Button variant="outline" size="sm">
                              Change Partner
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="schedule" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Tournament Schedule</CardTitle>
                <CardDescription>The schedule will be available after the draw on December 8th</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md bg-gray-50 p-6 text-center">
                  <Calendar className="mx-auto mb-4 h-12 w-12 text-gray-400" />
                  <h3 className="mb-2 text-lg font-medium">Schedule Not Available Yet</h3>
                  <p className="text-gray-600">
                    The tournament draw and schedule will be published on December 8th. Please check back later.
                  </p>
                </div>
                <div className="mt-6 rounded-md border p-4">
                  <h3 className="mb-4 font-medium">Important Dates</h3>
                  <div className="space-y-3">
                    <div className="flex items-start space-x-3">
                      <div className="rounded-full bg-[#0F766E] p-1 text-white">
                        <Calendar className="h-4 w-4" />
                      </div>
                      <div>
                        <p className="font-medium">December 7th</p>
                        <p className="text-sm text-gray-500">Last date for payment</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="rounded-full bg-[#0F766E] p-1 text-white">
                        <Calendar className="h-4 w-4" />
                      </div>
                      <div>
                        <p className="font-medium">December 8th</p>
                        <p className="text-sm text-gray-500">Draw and schedule announcement</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <div className="rounded-full bg-[#0F766E] p-1 text-white">
                        <Calendar className="h-4 w-4" />
                      </div>
                      <div>
                        <p className="font-medium">December 9-10th</p>
                        <p className="text-sm text-gray-500">Tournament days</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
