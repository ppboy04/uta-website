"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Download, Search, Users } from "lucide-react"

// Mock data for registered players and events
const events = [
  { id: "A", name: "Category A (Open)" },
  { id: "B", name: "Category B (90+ combined)" },
  { id: "C", name: "Category C (105+ combined)" },
  { id: "D", name: "Category D (120+ combined)" },
]

const registeredTeams = {
  A: [
    { id: 1, player1: "Amit Kumar", player2: "Rajesh Singh", ranking: "" },
    { id: 2, player1: "Vikram Sharma", player2: "Anil Kapoor", ranking: "" },
    { id: 3, player1: "Sunil Verma", player2: "Rahul Gupta", ranking: "" },
    { id: 4, player1: "Deepak Sharma", player2: "Nitin Patel", ranking: "" },
  ],
  B: [
    { id: 1, player1: "Amit Kumar", player2: "Vikram Sharma", ranking: "" },
    { id: 2, player1: "Rajesh Singh", player2: "Sunil Verma", ranking: "" },
    { id: 3, player1: "Anil Kapoor", player2: "Rahul Gupta", ranking: "" },
  ],
  C: [
    { id: 1, player1: "Rajesh Singh", player2: "Pending", ranking: "" },
    { id: 2, player1: "Sunil Verma", player2: "Deepak Sharma", ranking: "" },
  ],
  D: [{ id: 1, player1: "Vikram Sharma", player2: "Anil Kapoor", ranking: "" }],
}

const registeredPlayers = [
  { id: 1, name: "Amit Kumar", whatsapp: "9876543210", events: ["A", "B"], payment: "Paid" },
  { id: 2, name: "Rajesh Singh", whatsapp: "9876543211", events: ["A", "C"], payment: "Paid" },
  { id: 3, name: "Vikram Sharma", whatsapp: "9876543212", events: ["A", "B", "D"], payment: "Pending" },
  { id: 4, name: "Sunil Verma", whatsapp: "9876543213", events: ["A", "B", "C"], payment: "Paid" },
  { id: 5, name: "Anil Kapoor", whatsapp: "9876543214", events: ["A", "D"], payment: "Pending" },
  { id: 6, name: "Rahul Gupta", whatsapp: "9876543215", events: ["A", "B"], payment: "Paid" },
  { id: 7, name: "Deepak Sharma", whatsapp: "9876543216", events: ["A", "C"], payment: "Pending" },
  { id: 8, name: "Nitin Patel", whatsapp: "9876543217", events: ["A"], payment: "Paid" },
]

export default function AdminDashboardPage() {
  const [activeTab, setActiveTab] = useState("players")
  const [selectedEvent, setSelectedEvent] = useState("A")
  const [searchTerm, setSearchTerm] = useState("")
  const [teams, setTeams] = useState(registeredTeams)

  const handleRankingChange = (eventId: string, teamId: number, value: string) => {
    setTeams((prev) => ({
      ...prev,
      [eventId]: prev[eventId as keyof typeof prev].map((team) =>
        team.id === teamId ? { ...team, ranking: value } : team,
      ),
    }))
  }

  const handleSaveRankings = () => {
    // In a real application, you would save the rankings to your backend here
    alert("Rankings saved successfully!")
  }

  const filteredPlayers = registeredPlayers.filter(
    (player) => player.name.toLowerCase().includes(searchTerm.toLowerCase()) || player.whatsapp.includes(searchTerm),
  )

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mx-auto max-w-6xl">
        <div className="mb-8 flex items-center justify-between">
          <Link href="/" className="flex items-center text-[#0F766E] hover:underline">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>
          <Button variant="outline" className="text-red-600 hover:bg-red-50 hover:text-red-700">
            Logout
          </Button>
        </div>

        <div className="mb-8">
          <h1 className="text-3xl font-bold text-[#0F766E]">Admin Dashboard</h1>
          <p className="text-gray-600">Manage tournament registrations and rankings</p>
        </div>

        <div className="mb-6 grid grid-cols-1 gap-6 md:grid-cols-3">
          <Card>
            <CardContent className="flex items-center justify-between p-6">
              <div>
                <p className="text-sm font-medium text-gray-500">Total Players</p>
                <p className="text-3xl font-bold">{registeredPlayers.length}</p>
              </div>
              <div className="rounded-full bg-[#0F766E]/10 p-3 text-[#0F766E]">
                <Users className="h-6 w-6" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex items-center justify-between p-6">
              <div>
                <p className="text-sm font-medium text-gray-500">Payments Received</p>
                <p className="text-3xl font-bold">
                  {registeredPlayers.filter((p) => p.payment === "Paid").length}/{registeredPlayers.length}
                </p>
              </div>
              <div className="rounded-full bg-green-100 p-3 text-green-600">
                <svg
                  className="h-6 w-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"
                  />
                </svg>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex items-center justify-between p-6">
              <div>
                <p className="text-sm font-medium text-gray-500">Total Teams</p>
                <p className="text-3xl font-bold">{Object.values(teams).reduce((acc, curr) => acc + curr.length, 0)}</p>
              </div>
              <div className="rounded-full bg-blue-100 p-3 text-blue-600">
                <svg
                  className="h-6 w-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                  />
                </svg>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="players">Players</TabsTrigger>
            <TabsTrigger value="rankings">Team Rankings</TabsTrigger>
          </TabsList>

          <TabsContent value="players" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Registered Players</CardTitle>
                <CardDescription>View and manage all registered players</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-6 flex items-center space-x-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search by name or WhatsApp number"
                      className="pl-8"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  <Button variant="outline" className="flex items-center space-x-1">
                    <Download className="h-4 w-4" />
                    <span>Export</span>
                  </Button>
                </div>

                <div className="rounded-md border">
                  <div className="grid grid-cols-12 gap-2 border-b bg-gray-50 p-3 font-medium">
                    <div className="col-span-1">#</div>
                    <div className="col-span-3">Name</div>
                    <div className="col-span-2">WhatsApp</div>
                    <div className="col-span-3">Events</div>
                    <div className="col-span-2">Payment</div>
                    <div className="col-span-1">Actions</div>
                  </div>

                  {filteredPlayers.map((player, index) => (
                    <div key={player.id} className="grid grid-cols-12 gap-2 border-b p-3">
                      <div className="col-span-1">{index + 1}</div>
                      <div className="col-span-3">{player.name}</div>
                      <div className="col-span-2">{player.whatsapp}</div>
                      <div className="col-span-3">
                        <div className="flex flex-wrap gap-1">
                          {player.events.map((eventId) => (
                            <Badge key={eventId} variant="outline" className="bg-gray-100">
                              {events.find((e) => e.id === eventId)?.name.replace("Category ", "")}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div className="col-span-2">
                        <Badge
                          variant={player.payment === "Paid" ? "default" : "outline"}
                          className={
                            player.payment === "Paid" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"
                          }
                        >
                          {player.payment}
                        </Badge>
                      </div>
                      <div className="col-span-1">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <svg
                            className="h-4 w-4"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"
                            />
                          </svg>
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="rankings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Team Rankings</CardTitle>
                <CardDescription>Assign rankings to teams for tournament seeding</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-6">
                  <label htmlFor="event-select">Select Event</label>
                  <Select value={selectedEvent} onValueChange={setSelectedEvent}>
                    <SelectTrigger className="w-full md:w-[300px]">
                      <SelectValue placeholder="Select an event" />
                    </SelectTrigger>
                    <SelectContent>
                      {events.map((event) => (
                        <SelectItem key={event.id} value={event.id}>
                          {event.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="rounded-md border">
                  <div className="grid grid-cols-12 gap-2 border-b bg-gray-50 p-3 font-medium">
                    <div className="col-span-1">#</div>
                    <div className="col-span-4">Player 1</div>
                    <div className="col-span-4">Player 2</div>
                    <div className="col-span-3">Ranking</div>
                  </div>

                  {teams[selectedEvent as keyof typeof teams].map((team, index) => (
                    <div key={team.id} className="grid grid-cols-12 gap-2 border-b p-3">
                      <div className="col-span-1">{index + 1}</div>
                      <div className="col-span-4">{team.player1}</div>
                      <div className="col-span-4">
                        {team.player2 === "Pending" ? (
                          <Badge variant="outline" className="bg-yellow-100 text-yellow-800">
                            Partner Pending
                          </Badge>
                        ) : (
                          team.player2
                        )}
                      </div>
                      <div className="col-span-3">
                        <Input
                          type="number"
                          min="1"
                          placeholder="Enter ranking"
                          value={team.ranking}
                          onChange={(e) => handleRankingChange(selectedEvent, team.id, e.target.value)}
                          className="w-full"
                        />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 flex justify-end">
                  <Button onClick={handleSaveRankings} className="bg-[#0F766E] hover:bg-[#0c5954]">
                    Save Rankings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
