"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, ArrowRight } from "lucide-react"

export default function RegisterPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    name: "",
    whatsappNumber: "",
    dateOfBirth: "",
    city: "",
    shirtSize: "",
    shortSize: "",
    foodPreference: "",
    stayRequired: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Store form data in localStorage to access in the next step
    localStorage.setItem("registrationData", JSON.stringify(formData))
    router.push("/register/events")
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mx-auto max-w-3xl">
        <div className="mb-8 flex items-center justify-between">
          <Link href="/" className="flex items-center text-[#0F766E] hover:underline">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>
          <div className="text-sm text-gray-500">Step 1 of 2</div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-[#0F766E]">Player Registration</CardTitle>
            <CardDescription>Please provide your personal details to register for the tournament</CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Enter your full name"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="whatsappNumber">WhatsApp Number</Label>
                  <Input
                    id="whatsappNumber"
                    name="whatsappNumber"
                    value={formData.whatsappNumber}
                    onChange={handleChange}
                    placeholder="Enter your WhatsApp number"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dateOfBirth">Date of Birth</Label>
                  <Input
                    id="dateOfBirth"
                    name="dateOfBirth"
                    type="date"
                    value={formData.dateOfBirth}
                    onChange={handleChange}
                    required
                  />
                  <p className="text-xs text-gray-500">Age limit is 30 years as of December 9, 2023</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="city">City</Label>
                  <Input
                    id="city"
                    name="city"
                    value={formData.city}
                    onChange={handleChange}
                    placeholder="Enter your city"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="shirtSize">T-Shirt Size</Label>
                  <Select
                    value={formData.shirtSize}
                    onValueChange={(value) => handleSelectChange("shirtSize", value)}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select your T-shirt size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="S">Small (S)</SelectItem>
                      <SelectItem value="M">Medium (M)</SelectItem>
                      <SelectItem value="L">Large (L)</SelectItem>
                      <SelectItem value="XL">Extra Large (XL)</SelectItem>
                      <SelectItem value="XXL">Double XL (XXL)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="shortSize">Shorts Size</Label>
                  <Select
                    value={formData.shortSize}
                    onValueChange={(value) => handleSelectChange("shortSize", value)}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select your shorts size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="S">Small (S)</SelectItem>
                      <SelectItem value="M">Medium (M)</SelectItem>
                      <SelectItem value="L">Large (L)</SelectItem>
                      <SelectItem value="XL">Extra Large (XL)</SelectItem>
                      <SelectItem value="XXL">Double XL (XXL)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Food Preference</Label>
                <RadioGroup
                  value={formData.foodPreference}
                  onValueChange={(value) => handleSelectChange("foodPreference", value)}
                  required
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Vegetarian" id="vegetarian" />
                    <Label htmlFor="vegetarian">Vegetarian</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Non-Vegetarian" id="non-vegetarian" />
                    <Label htmlFor="non-vegetarian">Non-Vegetarian</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label>Accommodation Required</Label>
                <RadioGroup
                  value={formData.stayRequired}
                  onValueChange={(value) => handleSelectChange("stayRequired", value)}
                  required
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Yes" id="stay-yes" />
                    <Label htmlFor="stay-yes">Yes (Additional charges apply)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="No" id="stay-no" />
                    <Label htmlFor="stay-no">No</Label>
                  </div>
                </RadioGroup>
                <p className="text-xs text-gray-500">Double sharing accommodation for up to 2 days</p>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button type="submit" className="bg-[#0F766E] hover:bg-[#0c5954]">
                Next
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  )
}
