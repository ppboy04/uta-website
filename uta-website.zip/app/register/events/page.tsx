"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Check, Info } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

// Mock data for events and registered players
const events = [
  { id: "A", name: "Category A (Open)" },
  { id: "B", name: "Category B (90+ combined)" },
  { id: "C", name: "Category C (105+ combined)" },
  { id: "D", name: "Category D (120+ combined)" },
]

// Mock registered players data
const registeredPlayers = [
  { id: 1, name: "Amit Kumar", events: ["A", "B"] },
  { id: 2, name: "Rajesh Singh", events: ["A", "C"] },
  { id: 3, name: "Vikram Sharma", events: ["B", "D"] },
  { id: 4, name: "Sunil Verma", events: ["C"] },
  { id: 5, name: "Anil Kapoor", events: ["A", "D"] },
]

export default function EventsRegistrationPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    event1: "",
    partner1: "",
    event2: "",
    partner2: "",
  })
  const [personalData, setPersonalData] = useState<any>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [registrationComplete, setRegistrationComplete] = useState(false)

  useEffect(() => {
    // Retrieve personal data from localStorage
    const storedData = localStorage.getItem("registrationData")
    if (storedData) {
      setPersonalData(JSON.parse(storedData))
    } else {
      // Redirect to first step if no data is found
      router.push("/register")
    }
  }, [router])

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const getAvailablePartners = (eventId: string) => {
    // Filter players who have registered for this event
    return registeredPlayers.filter((player) => player.events.includes(eventId))
  }

  const calculateFee = () => {
    const eventsCount = (formData.event1 ? 1 : 0) + (formData.event2 ? 1 : 0)
    const basePrice = eventsCount === 2 ? 4500 : 3000
    const accommodationPrice = personalData?.stayRequired === "Yes" ? (eventsCount === 2 ? 1500 : 1500) : 0
    return basePrice + accommodationPrice
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Simulate API call to save data
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // In a real application, you would send the data to your backend here
      console.log("Registration data:", {
        personalData,
        eventData: formData,
      })

      // Show success message
      setRegistrationComplete(true)
    } catch (error) {
      console.error("Registration failed:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  if (registrationComplete) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="mx-auto max-w-3xl">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl text-[#0F766E]">Registration Complete!</CardTitle>
              <CardDescription>Thank you for registering for the UTA Doubles Tournament</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="rounded-lg bg-green-50 p-6 text-center">
                <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-green-100">
                  <Check className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="mb-2 text-lg font-medium">Registration Successful</h3>
                <p className="text-gray-600">
                  Your registration has been received. Please complete the payment of ₹{calculateFee()} by December 7th
                  to confirm your participation.
                </p>
              </div>

              <div className="space-y-4">
                <h4 className="font-medium">Registration Details:</h4>
                <div className="rounded-md bg-gray-50 p-4">
                  <p>
                    <strong>Name:</strong> {personalData?.name}
                  </p>
                  <p>
                    <strong>WhatsApp:</strong> {personalData?.whatsappNumber}
                  </p>
                  <p>
                    <strong>Events:</strong> {formData.event1 && events.find((e) => e.id === formData.event1)?.name}
                    {formData.event2 && `, ${events.find((e) => e.id === formData.event2)?.name}`}
                  </p>
                </div>
              </div>

              <Alert>
                <Info className="h-4 w-4" />
                <AlertTitle>Important</AlertTitle>
                <AlertDescription>
                  Please join the WhatsApp group for further updates and information about the tournament.
                </AlertDescription>
              </Alert>
            </CardContent>
            <CardFooter className="flex justify-center space-x-4">
              <Button asChild variant="outline">
                <Link href="/">Return to Home</Link>
              </Button>
              <Button asChild className="bg-[#0F766E] hover:bg-[#0c5954]">
                <a href="https://chat.whatsapp.com/JTvbjXSOolF7KI5ORr46DY" target="_blank" rel="noopener noreferrer">
                  Join WhatsApp Group
                </a>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mx-auto max-w-3xl">
        <div className="mb-8 flex items-center justify-between">
          <Link href="/register" className="flex items-center text-[#0F766E] hover:underline">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Personal Details
          </Link>
          <div className="text-sm text-gray-500">Step 2 of 2</div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-[#0F766E]">Select Events & Partners</CardTitle>
            <CardDescription>
              You can participate in up to 2 categories. Select your events and partners below.
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-8">
              <div className="space-y-6">
                <h3 className="text-lg font-medium">Event 1</h3>
                <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="event1">Select Category</Label>
                    <Select
                      value={formData.event1}
                      onValueChange={(value) => handleSelectChange("event1", value)}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                      <SelectContent>
                        {events.map((event) => (
                          <SelectItem key={event.id} value={event.id}>
                            {event.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="partner1">Select Partner</Label>
                    <Select
                      value={formData.partner1}
                      onValueChange={(value) => handleSelectChange("partner1", value)}
                      disabled={!formData.event1}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select your partner" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="not-registered">Partner not registered yet</SelectItem>
                        {formData.event1 &&
                          getAvailablePartners(formData.event1).map((player) => (
                            <SelectItem key={player.id} value={String(player.id)}>
                              {player.name}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium">Event 2 (Optional)</h3>
                  <p className="text-sm text-gray-500">You can participate in up to 2 events</p>
                </div>
                <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="event2">Select Category</Label>
                    <Select value={formData.event2} onValueChange={(value) => handleSelectChange("event2", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category (optional)" />
                      </SelectTrigger>
                      <SelectContent>
                        {events
                          .filter((event) => event.id !== formData.event1)
                          .map((event) => (
                            <SelectItem key={event.id} value={event.id}>
                              {event.name}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="partner2">Select Partner</Label>
                    <Select
                      value={formData.partner2}
                      onValueChange={(value) => handleSelectChange("partner2", value)}
                      disabled={!formData.event2}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select your partner" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="not-registered">Partner not registered yet</SelectItem>
                        {formData.event2 &&
                          getAvailablePartners(formData.event2).map((player) => (
                            <SelectItem key={player.id} value={String(player.id)}>
                              {player.name}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <div className="rounded-md bg-gray-50 p-4">
                <h3 className="mb-2 font-medium">Registration Fee</h3>
                <p className="text-lg font-semibold">₹{calculateFee()}</p>
                <p className="mt-1 text-sm text-gray-500">
                  {formData.event1 && formData.event2 ? "Two events" : "One event"}
                  {personalData?.stayRequired === "Yes" ? " with accommodation" : " without accommodation"}
                </p>
                <p className="mt-2 text-sm">
                  Payment details will be provided after registration. Last date for payment is December 7th.
                </p>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button type="button" variant="outline" onClick={() => router.push("/register")}>
                Back
              </Button>
              <Button
                type="submit"
                className="bg-[#0F766E] hover:bg-[#0c5954]"
                disabled={isSubmitting || !formData.event1 || !formData.partner1}
              >
                {isSubmitting ? "Submitting..." : "Complete Registration"}
              </Button>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  )
}
