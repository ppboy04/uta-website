import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Trophy, Users, Calendar, MapPin, Info } from "lucide-react"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="bg-[#0F766E] text-white">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col items-center justify-between space-y-4 md:flex-row md:space-y-0">
            <div className="flex items-center space-x-2">
              <Trophy className="h-8 w-8" />
              <h1 className="text-2xl font-bold">Uttaranchal Tennis Association</h1>
            </div>
            <div className="flex space-x-4">
              <Button asChild variant="outline" className="border-white text-white hover:bg-white hover:text-[#0F766E]">
                <Link href="/login">User Login</Link>
              </Button>
              <Button asChild variant="outline" className="border-white text-white hover:bg-white hover:text-[#0F766E]">
                <Link href="/register">Register</Link>
              </Button>
              <Button asChild variant="outline" className="border-white text-white hover:bg-white hover:text-[#0F766E]">
                <Link href="/admin/login">Admin Login</Link>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 bg-gray-50">
        <section className="container mx-auto px-4 py-12">
          <div className="mb-12 text-center">
            <h2 className="mb-2 text-3xl font-bold text-[#0F766E]">Annual Doubles Tournament 2023</h2>
            <p className="text-lg text-gray-600">
              Join us for the most exciting tennis doubles tournament in Uttaranchal
            </p>
          </div>

          <div className="mb-12 grid grid-cols-1 gap-6 md:grid-cols-3">
            <Card className="shadow-md">
              <CardContent className="flex flex-col items-center p-6">
                <Users className="mb-4 h-12 w-12 text-[#0F766E]" />
                <h3 className="mb-2 text-xl font-semibold">Multiple Categories</h3>
                <p className="text-center text-gray-600">
                  Participate in up to 2 categories from A, B, C, D, and Lucky Doubles
                </p>
              </CardContent>
            </Card>

            <Card className="shadow-md">
              <CardContent className="flex flex-col items-center p-6">
                <Calendar className="mb-4 h-12 w-12 text-[#0F766E]" />
                <h3 className="mb-2 text-xl font-semibold">December 9-10, 2023</h3>
                <p className="text-center text-gray-600">
                  Two days of competitive tennis with breakfast, lunch, and a gala dinner
                </p>
              </CardContent>
            </Card>

            <Card className="shadow-md">
              <CardContent className="flex flex-col items-center p-6">
                <Trophy className="mb-4 h-12 w-12 text-[#0F766E]" />
                <h3 className="mb-2 text-xl font-semibold">Attractive Prizes</h3>
                <p className="text-center text-gray-600">₹21,000 for winners, ₹11,000 for runners-up, and more</p>
              </CardContent>
            </Card>
          </div>

          <div className="rounded-lg bg-white p-6 shadow-md">
            <h3 className="mb-6 text-2xl font-bold text-[#0F766E]">Tournament Factsheet and Rules</h3>

            <div className="space-y-4">
              <div className="rounded-md bg-gray-50 p-4">
                <h4 className="mb-2 font-semibold">Categories</h4>
                <p>
                  A (Open), B (90+ combined), C (105+ combined), D (120+ combined), Lucky Doubles. This is Only Doubles
                  Tournament.
                </p>
              </div>

              <div className="rounded-md bg-gray-50 p-4">
                <h4 className="mb-2 font-semibold">Lucky Doubles Format</h4>
                <p>
                  Any participant who loses both the matches in the first round shall be considered for the draw of
                  Lucky Doubles. Any participant who opted for one event and loses in the first round will also be
                  eligible. Pairing up logic will be as follows: All the participants will be divided into X(Age&lt;=50
                  years) and Y(Age&gt;50 years) categories. Each pair will have one person from X category and one
                  person from Y category based on lottery system.
                </p>
              </div>

              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <div className="rounded-md bg-gray-50 p-4">
                  <h4 className="mb-2 font-semibold">Age Limit</h4>
                  <p>
                    Age Limit is 30 years. The age of any participant shall be calculated as his running age as on 9th
                    December. Please carry your age proof with you.
                  </p>
                </div>

                <div className="rounded-md bg-gray-50 p-4">
                  <h4 className="mb-2 font-semibold">Participation Rules</h4>
                  <p>
                    One player can participate in max 2 categories (excluding lucky doubles which could be the 3rd for
                    any participant). Coaches are allowed to play in Category A only.
                  </p>
                </div>

                <div className="rounded-md bg-gray-50 p-4">
                  <h4 className="mb-2 font-semibold">Entry Fee</h4>
                  <p>
                    Two events: ₹4500 (₹6000 with accommodation)
                    <br />
                    One event: ₹3000 (₹4500 with accommodation)
                  </p>
                </div>

                <div className="rounded-md bg-gray-50 p-4">
                  <h4 className="mb-2 font-semibold">Inclusions</h4>
                  <p>
                    Breakfast and Lunch on both days, Gala dinner on 9th December. Every participant shall get Indian
                    Tree T-Shirt, Shorts, Socks, Cap, Wristband (MRP more than Rs 3000).
                  </p>
                </div>

                <div className="rounded-md bg-gray-50 p-4">
                  <h4 className="mb-2 font-semibold">Prize Money</h4>
                  <p>
                    Winner team: ₹21,000
                    <br />
                    Runners-up team: ₹11,000
                    <br />
                    Each Semi-Finalist team: ₹4,000
                    <br />
                    Lucky Doubles Prize: 50% of regular prizes
                  </p>
                </div>

                <div className="rounded-md bg-gray-50 p-4">
                  <h4 className="mb-2 font-semibold">Important Dates</h4>
                  <p>
                    Last date for entry fees: 7th December
                    <br />
                    Draws and Order of Play: 8th December
                    <br />
                    Tournament: 9-10th December
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <div className="rounded-md bg-gray-50 p-4">
                  <h4 className="mb-2 font-semibold">Venue</h4>
                  <div className="flex items-start space-x-2">
                    <MapPin className="mt-1 h-5 w-5 flex-shrink-0 text-[#0F766E]" />
                    <div>
                      <p>Tournament: Shanti Tennis Academy</p>
                      <a
                        href="https://maps.app.goo.gl/fPLo9aK52WSihktY6"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[#0F766E] hover:underline"
                      >
                        View on Maps
                      </a>
                    </div>
                  </div>
                </div>

                <div className="rounded-md bg-gray-50 p-4">
                  <h4 className="mb-2 font-semibold">Gala Party and Stay</h4>
                  <div className="flex items-start space-x-2">
                    <MapPin className="mt-1 h-5 w-5 flex-shrink-0 text-[#0F766E]" />
                    <p>OM farms, 8-A, Jogiwala, Badripur, Dehradun, Uttarakhand 248005</p>
                  </div>
                </div>
              </div>

              <div className="rounded-md bg-gray-50 p-4">
                <h4 className="mb-2 font-semibold">Additional Information</h4>
                <ul className="list-inside list-disc space-y-2">
                  <li>The Maximum size of the draw in any category is 32.</li>
                  <li>There are 4 hard courts and 4 additional hard courts at a nearby venue if required.</li>
                  <li>Balls for the Tournament shall be Head Tour.</li>
                  <li>
                    If any team does not turn up at scheduled time, walk-over shall be given to the opponent within 15
                    minutes.
                  </li>
                  <li>For any query Please contact Tournament Director Sumit Goel (Ph. 9412977857)</li>
                </ul>
              </div>

              <div className="rounded-md bg-gray-50 p-4">
                <h4 className="mb-2 font-semibold">Links</h4>
                <div className="space-y-2">
                  <p>
                    <Info className="mr-2 inline h-4 w-4 text-[#0F766E]" />
                    <a
                      href="https://tinyurl.com/UK2023ENTRIES"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#0F766E] hover:underline"
                    >
                      List of participants Registered so far
                    </a>
                  </p>
                  <p>
                    <Users className="mr-2 inline h-4 w-4 text-[#0F766E]" />
                    <a
                      href="https://chat.whatsapp.com/JTvbjXSOolF7KI5ORr46DY"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#0F766E] hover:underline"
                    >
                      Join participants WhatsApp group
                    </a>
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-12 flex justify-center">
            <Button asChild size="lg" className="bg-[#0F766E] hover:bg-[#0c5954]">
              <Link href="/register">Register Now</Link>
            </Button>
          </div>
        </section>
      </main>

      <footer className="bg-[#0F766E] py-6 text-white">
        <div className="container mx-auto px-4 text-center">
          <p>© {new Date().getFullYear()} Uttaranchal Tennis Association. All rights reserved.</p>
          <p className="mt-2">For queries: Contact Tournament Director Sumit Goel (Ph. 9412977857)</p>
        </div>
      </footer>
    </div>
  )
}
