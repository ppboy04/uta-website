// Player types
export interface Player {
  id: number
  name: string
  whatsappNumber: string
  dateOfBirth: string
  city: string
  shirtSize: string
  shortSize: string
  foodPreference: string
  stayRequired: string
  feePaid: boolean
}

// Event types
export interface Event {
  id: string
  name: string
}

// Partner types
export interface Partner {
  id: number
  eventName: string
  userId: number
  partnerId: number | null
  ranking: number | null
}

// Registration form data types
export interface RegistrationFormData {
  name: string
  whatsappNumber: string
  dateOfBirth: string
  city: string
  shirtSize: string
  shortSize: string
  foodPreference: string
  stayRequired: string
}

export interface EventsFormData {
  event1: string
  partner1: string
  event2: string
  partner2: string
}
