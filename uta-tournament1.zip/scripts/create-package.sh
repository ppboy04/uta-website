#!/bin/bash

# Script to create the complete UTA Tournament website package
echo "🏆 Creating UTA Tournament Website Package..."

# Set package name and version
PACKAGE_NAME="uta-tournament-website"
VERSION="1.0.0"
DATE=$(date +%Y%m%d)
PACKAGE_FILE="${PACKAGE_NAME}-v${VERSION}-${DATE}.zip"

# Create temporary directory
TEMP_DIR="/tmp/${PACKAGE_NAME}"
rm -rf $TEMP_DIR
mkdir -p $TEMP_DIR

echo "📁 Creating directory structure..."

# Create all necessary directories
mkdir -p $TEMP_DIR/{app/{api/{register,events,players,rankings,login},register/success,login,player-dashboard,admin-dashboard/players},components/{ui},lib,hooks,scripts,public}

echo "📄 Package ready for file copying..."
echo ""
echo "To complete the package creation:"
echo "1. Copy all your project files to: $TEMP_DIR"
echo "2. Run: cd /tmp && zip -r $PACKAGE_FILE $PACKAGE_NAME"
echo "3. The package will be ready at: /tmp/$PACKAGE_FILE"
echo ""
echo "📋 Required files checklist:"
echo "✅ package.json"
echo "✅ next.config.mjs"
echo "✅ tailwind.config.ts"
echo "✅ tsconfig.json"
echo "✅ .env.example"
echo "✅ README.md"
echo "✅ app/layout.tsx"
echo "✅ app/page.tsx"
echo "✅ app/globals.css"
echo "✅ All component files"
echo "✅ All API route files"
echo "✅ Database scripts"
echo "✅ Installation guide"
echo ""
echo "🚀 After creating the zip file, your client can:"
echo "1. Upload the zip file to their server"
echo "2. Extract it"
echo "3. Follow the installation guide"
echo "4. Have a working tournament website!"

# Create a simple file list for verification
cat > $TEMP_DIR/FILE_LIST.txt << EOF
UTA Tournament Website Package Contents
======================================

Root Files:
- package.json (Node.js dependencies)
- next.config.mjs (Next.js configuration)
- tailwind.config.ts (Tailwind CSS configuration)
- tsconfig.json (TypeScript configuration)
- .env.example (Environment variables template)
- README.md (Project documentation)

App Directory:
- app/layout.tsx (Root layout)
- app/page.tsx (Home page)
- app/globals.css (Global styles)
- app/login/page.tsx (Login page)
- app/register/page.tsx (Registration page)
- app/register/success/page.tsx (Registration success)
- app/player-dashboard/page.tsx (Player dashboard)
- app/admin-dashboard/page.tsx (Admin dashboard)
- app/admin-dashboard/players/page.tsx (Admin players list)

API Routes:
- app/api/register/route.ts (Player registration API)
- app/api/events/route.ts (Events API)
- app/api/players/[event]/route.ts (Players by event API)
- app/api/rankings/route.ts (Rankings API)

Components:
- components/landing-page.tsx (Home page component)
- components/registration-form.tsx (Registration form)
- components/player-dashboard.tsx (Player dashboard)
- components/admin-dashboard.tsx (Admin dashboard)
- components/admin-players-list.tsx (Admin players list)
- components/ui/* (UI components from shadcn/ui)

Database Scripts:
- scripts/create-tables.sql (Database schema)
- scripts/seed-data.sql (Sample data)

Installation:
- UTA_Tournament_Installation_Instructions.md (Complete setup guide)

Total Files: 25+ files
Package Size: ~2-5 MB
Installation Time: 30-45 minutes
EOF

echo "📦 Package structure created at: $TEMP_DIR"
echo "📋 File list created for verification"
echo ""
echo "Next steps:"
echo "1. Copy your actual project files to $TEMP_DIR"
echo "2. Create the zip package"
echo "3. Test the package on a clean server"
echo "4. Provide to your client with installation guide"
