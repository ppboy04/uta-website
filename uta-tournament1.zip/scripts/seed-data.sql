-- UTA Tournament Sample Data
-- Run this script after create-tables.sql to populate initial data

USE uta_tournament;

-- Insert event categories
INSERT INTO tbl_eventName (id, event_name, description, entry_fee) VALUES
('a', 'Category A (Open)', 'Open category for all eligible players. Coaches are only allowed in this category.', 3000.00),
('b', 'Category B (90+ combined)', 'For pairs with a combined age of 90 years or more', 3000.00),
('c', 'Category C (105+ combined)', 'For pairs with a combined age of 105 years or more', 3000.00),
('d', 'Category D (120+ combined)', 'For pairs with a combined age of 120 years or more', 3000.00),
('lucky', 'Lucky Doubles', 'For players who lose both matches in round 1. Lottery pairing system.', 0.00);

-- Insert default admin user (username: admin, password: admin123)
-- Password hash generated with bcrypt rounds=12
INSERT INTO tbl_admin_users (username, password_hash, email, role) VALUES
('admin', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj3L3jzjvQSG', 'admin@utatournament.com', 'super_admin');

-- Insert sample players for testing
INSERT INTO tbl_players (name, whatsapp_number, dob, city, shirt_size, short_size, food_pref, stay, fee_paid, registration_id) VALUES
('Rahul Sharma', '9876543210', '1988-06-15', 'Dehradun', 'L', 'M', 'veg', TRUE, TRUE, 'UTA-2024-001'),
('Vikram Singh', '9876543211', '1985-08-22', 'Delhi', 'XL', 'L', 'nonveg', FALSE, TRUE, 'UTA-2024-002'),
('Amit Patel', '9876543212', '1991-03-10', 'Mumbai', 'M', 'M', 'veg', TRUE, TRUE, 'UTA-2024-003'),
('Suresh Kumar', '9876543213', '1987-11-05', 'Dehradun', 'L', 'L', 'nonveg', FALSE, TRUE, 'UTA-2024-004'),
('Rajesh Gupta', '9876543214', '1978-07-20', 'Chandigarh', 'XL', 'L', 'veg', TRUE, TRUE, 'UTA-2024-005'),
('Mohan Lal', '9876543215', '1975-09-12', 'Dehradun', 'L', 'M', 'veg', FALSE, FALSE, 'UTA-2024-006'),
('Dinesh Sharma', '9876543216', '1976-04-25', 'Lucknow', 'XXL', 'XL', 'nonveg', TRUE, TRUE, 'UTA-2024-007'),
('Prakash Jha', '9876543217', '1977-12-30', 'Dehradun', 'L', 'L', 'veg', FALSE, TRUE, 'UTA-2024-008'),
('Ramesh Verma', '9876543218', '1971-02-18', 'Delhi', 'M', 'M', 'veg', TRUE, TRUE, 'UTA-2024-009'),
('Sunil Kapoor', '9876543219', '1968-05-07', 'Dehradun', 'L', 'M', 'nonveg', FALSE, FALSE, 'UTA-2024-010');

-- Insert sample partnerships
INSERT INTO tbl_partners (event_name, user_id, partner_id, ranking, status) VALUES
('a', 1, 2, 1, 'confirmed'),
('a', 3, 4, 2, 'confirmed'),
('b', 5, 6, 1, 'confirmed'),
('b', 7, 8, 2, 'confirmed'),
('c', 9, 10, 1, 'confirmed'),
('c', 1, 5, 2, 'confirmed'),
('d', 6, 9, 1, 'confirmed');

-- Insert tournament settings
INSERT INTO tbl_tournament_settings (setting_key, setting_value, description) VALUES
('tournament_name', 'UTA Doubles Tournament 2024', 'Official tournament name'),
('tournament_date_start', '2024-12-08', 'Tournament start date'),
('tournament_date_end', '2024-12-09', 'Tournament end date'),
('registration_deadline', '2024-12-07', 'Last date for registration'),
('venue_name', 'Shanti Tennis Academy', 'Tournament venue'),
('venue_address', 'Dehradun, Uttarakhand', 'Venue address'),
('max_teams_per_category', '32', 'Maximum teams allowed per category'),
('entry_fee_single', '3000', 'Entry fee for single event'),
('entry_fee_double', '4500', 'Entry fee for two events'),
('stay_fee_single', '1500', 'Additional fee for accommodation (single event)'),
('stay_fee_double', '1500', 'Additional fee for accommodation (two events)'),
('contact_person', 'Sumit Goel', 'Tournament director name'),
('contact_phone', '9412977857', 'Contact phone number'),
('contact_email', 'admin@utatournament.com', 'Contact email address');

-- Insert sample audit log entries
INSERT INTO tbl_audit_log (user_type, user_id, action, table_name, record_id, ip_address, user_agent) VALUES
('admin', 1, 'CREATE_PLAYER', 'tbl_players', 1, '127.0.0.1', 'Mozilla/5.0 (System Setup)'),
('admin', 1, 'CREATE_PARTNERSHIP', 'tbl_partners', 1, '127.0.0.1', 'Mozilla/5.0 (System Setup)'),
('player', 1, 'LOGIN', 'tbl_players', 1, '127.0.0.1', 'Mozilla/5.0 (Test Login)');

-- Create views for easier data access
CREATE OR REPLACE VIEW vw_player_partnerships AS
SELECT 
    p.id as partnership_id,
    p.event_name,
    e.event_name as event_display_name,
    p1.id as player1_id,
    p1.name as player1_name,
    p1.whatsapp_number as player1_phone,
    YEAR(CURDATE()) - YEAR(p1.dob) as player1_age,
    p2.id as player2_id,
    p2.name as player2_name,
    p2.whatsapp_number as player2_phone,
    YEAR(CURDATE()) - YEAR(p2.dob) as player2_age,
    (YEAR(CURDATE()) - YEAR(p1.dob)) + (YEAR(CURDATE()) - YEAR(p2.dob)) as combined_age,
    p.ranking,
    p.status,
    p.created_at
FROM tbl_partners p
JOIN tbl_eventName e ON p.event_name = e.id
JOIN tbl_players p1 ON p.user_id = p1.id
LEFT JOIN tbl_players p2 ON p.partner_id = p2.id
WHERE p.status = 'confirmed'
ORDER BY p.event_name, p.ranking;

-- Create view for player statistics
CREATE OR REPLACE VIEW vw_player_stats AS
SELECT 
    p.id,
    p.name,
    p.whatsapp_number,
    p.city,
    YEAR(CURDATE()) - YEAR(p.dob) as age,
    p.fee_paid,
    p.stay,
    COUNT(pt.id) as events_registered,
    GROUP_CONCAT(e.event_name SEPARATOR ', ') as events_list,
    p.created_at as registration_date
FROM tbl_players p
LEFT JOIN tbl_partners pt ON p.id = pt.user_id AND pt.status = 'confirmed'
LEFT JOIN tbl_eventName e ON pt.event_name = e.id
WHERE p.status = 'active'
GROUP BY p.id
ORDER BY p.created_at DESC;

-- Create indexes for better performance
CREATE INDEX idx_players_age ON tbl_players((YEAR(CURDATE()) - YEAR(dob)));
CREATE INDEX idx_partnerships_combined ON tbl_partners(event_name, ranking, status);

-- Update table statistics
ANALYZE TABLE tbl_eventName, tbl_players, tbl_partners, tbl_admin_users, tbl_tournament_settings;

SELECT 'Sample data inserted successfully!' as Status;
SELECT 'Total Players:', COUNT(*) FROM tbl_players;
SELECT 'Total Partnerships:', COUNT(*) FROM tbl_partners;
SELECT 'Total Events:', COUNT(*) FROM tbl_eventName;
