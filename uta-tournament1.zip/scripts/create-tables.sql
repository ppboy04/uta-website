-- UTA Tournament Database Schema
-- Run this script first to create all required tables

USE uta_tournament;

-- Create events table
CREATE TABLE IF NOT EXISTS tbl_eventName (
    id VARCHAR(10) PRIMARY KEY,
    event_name VARCHAR(100) NOT NULL,
    description TEXT,
    max_teams INT DEFAULT 32,
    entry_fee DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create players table
CREATE TABLE IF NOT EXISTS tbl_players (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    whatsapp_number VARCHAR(15) NOT NULL UNIQUE,
    dob DATE NOT NULL,
    city VARCHAR(100) NOT NULL,
    shirt_size ENUM('S', 'M', 'L', 'XL', 'XXL') NOT NULL,
    short_size ENUM('S', 'M', 'L', 'XL', 'XXL') NOT NULL,
    food_pref ENUM('veg', 'nonveg') NOT NULL DEFAULT 'veg',
    stay BOOLEAN NOT NULL DEFAULT FALSE,
    fee_paid BOOLEAN NOT NULL DEFAULT FALSE,
    registration_id VARCHAR(20) UNIQUE,
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_whatsapp (whatsapp_number),
    INDEX idx_registration (registration_id),
    INDEX idx_status (status),
    INDEX idx_dob (dob),
    INDEX idx_city (city)
);

-- Create partners table
CREATE TABLE IF NOT EXISTS tbl_partners (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(10) NOT NULL,
    user_id INT NOT NULL,
    partner_id INT,
    ranking INT DEFAULT 0,
    status ENUM('registered', 'confirmed', 'withdrawn') DEFAULT 'registered',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (event_name) REFERENCES tbl_eventName(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES tbl_players(id) ON DELETE CASCADE,
    FOREIGN KEY (partner_id) REFERENCES tbl_players(id) ON DELETE SET NULL,
    
    UNIQUE KEY unique_user_event (user_id, event_name),
    INDEX idx_event (event_name),
    INDEX idx_ranking (ranking, event_name),
    INDEX idx_status (status)
);

-- Create admin users table
CREATE TABLE IF NOT EXISTS tbl_admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    role ENUM('admin', 'super_admin') DEFAULT 'admin',
    last_login TIMESTAMP NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_username (username),
    INDEX idx_status (status),
    INDEX idx_role (role)
);

-- Create audit log table for tracking changes
CREATE TABLE IF NOT EXISTS tbl_audit_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_type ENUM('player', 'admin') NOT NULL,
    user_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(50),
    record_id INT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_user (user_type, user_id),
    INDEX idx_action (action),
    INDEX idx_created (created_at),
    INDEX idx_table (table_name)
);

-- Create sessions table for user sessions
CREATE TABLE IF NOT EXISTS tbl_sessions (
    id VARCHAR(255) PRIMARY KEY,
    user_type ENUM('player', 'admin') NOT NULL,
    user_id INT NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_user (user_type, user_id),
    INDEX idx_expires (expires_at)
);

-- Create tournament settings table
CREATE TABLE IF NOT EXISTS tbl_tournament_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_key (setting_key)
);

-- Optimize tables
OPTIMIZE TABLE tbl_eventName, tbl_players, tbl_partners, tbl_admin_users, tbl_audit_log, tbl_sessions, tbl_tournament_settings;

-- Analyze tables for better query performance
ANALYZE TABLE tbl_eventName, tbl_players, tbl_partners, tbl_admin_users, tbl_audit_log, tbl_sessions, tbl_tournament_settings;

SELECT 'Database schema created successfully!' as Status;
