"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Calendar } from "lucide-react"

export default function LoginPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("player")
  const [playerFormData, setPlayerFormData] = useState({
    whatsappNumber: "",
    dob: "",
  })
  const [adminFormData, setAdminFormData] = useState({
    username: "",
    password: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handlePlayerInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setPlayerFormData((prev) => ({ ...prev, [name]: value }))
    setError("")
  }

  const handleAdminInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setAdminFormData((prev) => ({ ...prev, [name]: value }))
    setError("")
  }

  const handlePlayerLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // For demo purposes, redirect to player dashboard
      router.push("/player-dashboard")
    } catch (error) {
      console.error("Login error:", error)
      setError("Invalid login credentials. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Check for demo credentials
      if (adminFormData.username === "admin" && adminFormData.password === "admin123") {
        router.push("/admin-dashboard")
      } else {
        setError("Invalid admin credentials. Please try again.")
      }
    } catch (error) {
      console.error("Login error:", error)
      setError("An error occurred during login. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-md mx-auto">
          <div className="mb-8">
            <Link href="/" className="text-slate-600 hover:text-slate-900 flex items-center gap-2 transition-colors">
              <ArrowLeft className="h-4 w-4" />
              <span>Back to Home</span>
            </Link>
          </div>

          <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-bold bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent">
                Welcome Back
              </CardTitle>
              <CardDescription className="text-lg">Access your UTA Tournament account</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="player" onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-2 bg-slate-100">
                  <TabsTrigger
                    value="player"
                    className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white"
                  >
                    Player Login
                  </TabsTrigger>
                  <TabsTrigger
                    value="admin"
                    className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white"
                  >
                    Admin Login
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="player">
                  <form onSubmit={handlePlayerLogin} className="space-y-6 mt-6">
                    <div className="space-y-2">
                      <Label htmlFor="whatsappNumber" className="text-sm font-medium">
                        WhatsApp Number
                      </Label>
                      <Input
                        id="whatsappNumber"
                        name="whatsappNumber"
                        value={playerFormData.whatsappNumber}
                        onChange={handlePlayerInputChange}
                        placeholder="Enter your WhatsApp number"
                        className="h-12"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="dob" className="text-sm font-medium">
                        Date of Birth
                      </Label>
                      <div className="relative">
                        <Input
                          id="dob"
                          name="dob"
                          type="date"
                          value={playerFormData.dob}
                          onChange={handlePlayerInputChange}
                          className="h-12"
                          required
                        />
                        <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 pointer-events-none h-4 w-4" />
                      </div>
                    </div>

                    {error && (
                      <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                        <p className="text-sm text-red-600">{error}</p>
                      </div>
                    )}

                    <Button
                      type="submit"
                      className="w-full h-12 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-lg font-medium"
                      disabled={isLoading}
                    >
                      {isLoading ? "Logging in..." : "Login to Dashboard"}
                    </Button>
                  </form>
                </TabsContent>

                <TabsContent value="admin">
                  <form onSubmit={handleAdminLogin} className="space-y-6 mt-6">
                    <div className="space-y-2">
                      <Label htmlFor="username" className="text-sm font-medium">
                        Admin Username
                      </Label>
                      <Input
                        id="username"
                        name="username"
                        value={adminFormData.username}
                        onChange={handleAdminInputChange}
                        placeholder="Enter admin username"
                        className="h-12"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="password" className="text-sm font-medium">
                        Password
                      </Label>
                      <Input
                        id="password"
                        name="password"
                        type="password"
                        value={adminFormData.password}
                        onChange={handleAdminInputChange}
                        placeholder="Enter password"
                        className="h-12"
                        required
                      />
                    </div>

                    {error && (
                      <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                        <p className="text-sm text-red-600">{error}</p>
                      </div>
                    )}

                    <Button
                      type="submit"
                      className="w-full h-12 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-lg font-medium"
                      disabled={isLoading}
                    >
                      {isLoading ? "Logging in..." : "Admin Login"}
                    </Button>

                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                      <p className="text-xs text-blue-600">
                        <strong>Demo Credentials:</strong>
                        <br />
                        Username: admin
                        <br />
                        Password: admin123
                      </p>
                    </div>
                  </form>
                </TabsContent>
              </Tabs>
            </CardContent>
            <CardFooter className="flex justify-center bg-slate-50 rounded-b-lg">
              <p className="text-sm text-slate-600">
                Don't have an account?{" "}
                <Link href="/register" className="text-blue-600 hover:text-blue-700 font-medium hover:underline">
                  Register now
                </Link>
              </p>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}
