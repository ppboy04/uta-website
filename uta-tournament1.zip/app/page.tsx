import LandingPage from "@/components/landing-page"

export default function Home() {
  return <LandingPage />
}
