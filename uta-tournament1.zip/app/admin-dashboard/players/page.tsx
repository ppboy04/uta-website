import AdminPlayersList from "@/components/admin-players-list"

export default function AdminPlayersPage() {
  return <AdminPlayersList />
}
