import { NextResponse } from "next/server"

// In a real application, this would connect to your MySQL database
export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validate the data
    if (!data.name || !data.whatsappNumber || !data.dob) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // In a real application, you would insert this data into your database
    console.log("Registering player:", data)

    // Return a success response
    return NextResponse.json(
      {
        success: true,
        message: "Registration successful",
        playerId: `UTA-2024-${Math.floor(100000 + Math.random() * 900000)}`,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Error registering player:", error)
    return NextResponse.json({ error: "Failed to register player" }, { status: 500 })
  }
}
