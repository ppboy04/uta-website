import { NextResponse } from "next/server"

// In a real application, this would fetch from your MySQL database
export async function GET(request: Request, { params }: { params: { event: string } }) {
  try {
    const eventId = params.event

    if (!eventId) {
      return NextResponse.json({ error: "Event ID is required" }, { status: 400 })
    }

    // Mock players data
    const allPlayers = [
      { id: "p1", name: "Rahul Sharma", age: 35, paired: false },
      { id: "p2", name: "Vikram Singh", age: 38, paired: true },
      { id: "p3", name: "Amit Patel", age: 32, paired: true },
      { id: "p4", name: "Suresh Kumar", age: 36, paired: true },
      { id: "p5", name: "Rajesh Gupta", age: 45, paired: false },
      { id: "p6", name: "Mohan Lal", age: 48, paired: true },
      { id: "p7", name: "Dinesh Sharma", age: 47, paired: true },
      { id: "p8", name: "Prakash Jha", age: 46, paired: false },
      { id: "p9", name: "Ramesh Verma", age: 52, paired: true },
      { id: "p10", name: "Sunil Kapoor", age: 55, paired: true },
    ]

    // Filter players who are not paired yet
    const availablePlayers = allPlayers.filter((player) => !player.paired)

    return NextResponse.json({ players: availablePlayers })
  } catch (error) {
    console.error("Error fetching players:", error)
    return NextResponse.json({ error: "Failed to fetch players" }, { status: 500 })
  }
}
