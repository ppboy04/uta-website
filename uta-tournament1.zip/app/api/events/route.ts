import { NextResponse } from "next/server"

// In a real application, this would fetch from your MySQL database
export async function GET() {
  try {
    // Mock events data
    const events = [
      { id: "a", name: "Category A (Open)" },
      { id: "b", name: "Category B (90+ combined)" },
      { id: "c", name: "Category C (105+ combined)" },
      { id: "d", name: "Category D (120+ combined)" },
      { id: "lucky", name: "Lucky Doubles" },
    ]

    return NextResponse.json({ events })
  } catch (error) {
    console.error("Error fetching events:", error)
    return NextResponse.json({ error: "Failed to fetch events" }, { status: 500 })
  }
}
