import PlayerDashboard from "@/components/player-dashboard"

export default function PlayerDashboardPage() {
  return <PlayerDashboard />
}
