# UTA Tournament Management System

A complete web application for managing tennis tournament registrations, player management, and rankings.

## Features

- ✅ Player registration system
- ✅ Admin dashboard for tournament management
- ✅ Partner selection and pairing
- ✅ Ranking management
- ✅ Responsive design for mobile and desktop
- ✅ Secure authentication system
- ✅ MySQL database integration

## Technology Stack

- **Frontend:** React 18, Next.js 14, Tailwind CSS
- **Backend:** Next.js API Routes, Node.js
- **Database:** MySQL 8.0
- **UI Components:** shadcn/ui, Radix UI
- **Icons:** Lucide React

## Installation

1. **Prerequisites:**
   - Node.js 18+ installed
   - MySQL database (AWS RDS recommended)
   - AWS EC2 instance (Ubuntu 22.04 LTS)

2. **Setup:**
   \`\`\`bash
   # Extract the project files
   unzip uta-tournament-website.zip
   cd uta-tournament-website
   
   # Install dependencies
   npm install
   
   # Copy environment file
   cp .env.example .env.local
   # Edit .env.local with your database credentials
   
   # Build the application
   npm run build
   
   # Start the application
   npm start
   \`\`\`

3. **Database Setup:**
   \`\`\`bash
   # Run the SQL scripts in order:
   mysql -h your-host -u admin -p < scripts/create-tables.sql
   mysql -h your-host -u admin -p < scripts/seed-data.sql
   \`\`\`

## Default Credentials

### Admin Login:
- Username: `admin`
- Password: `admin123`

### Test Player Login:
- WhatsApp: `9876543210`
- DOB: `1988-06-15`

## Project Structure

\`\`\`
uta-tournament-website/
├── app/                    # Next.js app directory
│   ├── api/               # API routes
│   ├── login/             # Login page
│   ├── register/          # Registration pages
│   ├── player-dashboard/  # Player dashboard
│   ├── admin-dashboard/   # Admin dashboard
│   └── globals.css        # Global styles
├── components/            # React components
│   ├── ui/               # UI components (shadcn/ui)
│   └── ...               # Custom components
├── lib/                  # Utility functions
├── hooks/                # Custom React hooks
├── scripts/              # Database scripts
├── public/               # Static assets
└── package.json          # Dependencies
\`\`\`

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm run lint` - Run ESLint

## Environment Variables

Copy `.env.example` to `.env.local` and update with your values:

- `DATABASE_URL` - MySQL connection string
- `DB_HOST` - Database host
- `DB_USER` - Database username
- `DB_PASSWORD` - Database password
- `NEXTAUTH_SECRET` - Secret for authentication
- `JWT_SECRET` - Secret for JWT tokens

## Deployment

For detailed deployment instructions, see `UTA_Tournament_Installation_Instructions.md`

## Support

For technical support or questions:
- Check the installation guide
- Review the troubleshooting section
- Contact: support@yourcompany.com

## License

MIT License - see LICENSE file for details.
