// API service for making requests to the backend

// Player registration
export async function registerPlayer(playerData: any) {
  try {
    const response = await fetch("/api/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(playerData),
    })

    return await response.json()
  } catch (error) {
    console.error("Error registering player:", error)
    throw error
  }
}

// Get all events
export async function getEvents() {
  try {
    const response = await fetch("/api/events")
    return await response.json()
  } catch (error) {
    console.error("Error fetching events:", error)
    throw error
  }
}

// Get available players for an event
export async function getAvailablePlayers(eventId: string) {
  try {
    const response = await fetch(`/api/players/${eventId}`)
    return await response.json()
  } catch (error) {
    console.error("Error fetching available players:", error)
    throw error
  }
}

// Update rankings
export async function updateRankings(eventId: string, rankings: any[]) {
  try {
    const response = await fetch("/api/rankings", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        eventId,
        rankings,
      }),
    })

    return await response.json()
  } catch (error) {
    console.error("Error updating rankings:", error)
    throw error
  }
}

// Player login
export async function playerLogin(whatsappNumber: string, dob: string) {
  try {
    const response = await fetch("/api/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        whatsappNumber,
        dob,
      }),
    })

    return await response.json()
  } catch (error) {
    console.error("Error during login:", error)
    throw error
  }
}

// Get player details
export async function getPlayerDetails(playerId: string) {
  try {
    const response = await fetch(`/api/players/details/${playerId}`)
    return await response.json()
  } catch (error) {
    console.error("Error fetching player details:", error)
    throw error
  }
}

// Update player details
export async function updatePlayerDetails(playerId: string, playerData: any) {
  try {
    const response = await fetch(`/api/players/details/${playerId}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(playerData),
    })

    return await response.json()
  } catch (error) {
    console.error("Error updating player details:", error)
    throw error
  }
}
