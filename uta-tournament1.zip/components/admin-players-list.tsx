"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ArrowLeft, LogOut, Search, User } from "lucide-react"

export default function AdminPlayersList() {
  const [searchQuery, setSearchQuery] = useState("")

  // Mock players data
  const players = [
    {
      id: "p1",
      name: "Rahul Sharma",
      whatsappNumber: "9876543210",
      city: "Dehradun",
      age: 35,
      events: ["Category A", "Category C"],
    },
    { id: "p2", name: "Vikram Singh", whatsappNumber: "9876543211", city: "Delhi", age: 38, events: ["Category A"] },
    { id: "p3", name: "Amit Patel", whatsappNumber: "9876543212", city: "Mumbai", age: 32, events: ["Category A"] },
    {
      id: "p4",
      name: "Suresh Kumar",
      whatsappNumber: "9876543213",
      city: "Dehradun",
      age: 36,
      events: ["Category A", "Category B"],
    },
    {
      id: "p5",
      name: "Rajesh Gupta",
      whatsappNumber: "9876543214",
      city: "Chandigarh",
      age: 45,
      events: ["Category B", "Category C"],
    },
    { id: "p6", name: "Mohan Lal", whatsappNumber: "9876543215", city: "Dehradun", age: 48, events: ["Category B"] },
    { id: "p7", name: "Dinesh Sharma", whatsappNumber: "9876543216", city: "Lucknow", age: 47, events: ["Category B"] },
    {
      id: "p8",
      name: "Prakash Jha",
      whatsappNumber: "9876543217",
      city: "Dehradun",
      age: 46,
      events: ["Category B", "Category C"],
    },
    { id: "p9", name: "Ramesh Verma", whatsappNumber: "9876543218", city: "Delhi", age: 52, events: ["Category C"] },
    {
      id: "p10",
      name: "Sunil Kapoor",
      whatsappNumber: "9876543219",
      city: "Dehradun",
      age: 55,
      events: ["Category C", "Category D"],
    },
  ]

  const filteredPlayers = players.filter((player) => {
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      return (
        player.name.toLowerCase().includes(query) ||
        player.city.toLowerCase().includes(query) ||
        player.whatsappNumber.includes(query)
      )
    }
    return true
  })

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/" className="flex items-center gap-3">
            <div>
              <h1 className="text-xl font-bold text-slate-800">UTA Tournament</h1>
              <p className="text-sm text-slate-500">Admin Dashboard</p>
            </div>
          </Link>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="bg-slate-100 rounded-full p-1">
                <User className="h-5 w-5 text-slate-600" />
              </div>
              <span className="text-sm font-medium">Admin</span>
            </div>
            <Link href="/login">
              <Button variant="ghost" size="sm">
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <Link href="/admin-dashboard" className="text-slate-600 hover:text-slate-900 flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              <span>Back to Dashboard</span>
            </Link>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">All Players</CardTitle>
              <CardDescription>View and manage all registered players</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6">
                <div className="flex flex-col md:flex-row gap-4 md:items-end">
                  <div className="grid gap-2 flex-1">
                    <Label htmlFor="search">Search Players</Label>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                      <Input
                        id="search"
                        placeholder="Search by name, city, or WhatsApp number"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                </div>

                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>WhatsApp Number</TableHead>
                        <TableHead>City</TableHead>
                        <TableHead>Age</TableHead>
                        <TableHead>Events</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredPlayers.length > 0 ? (
                        filteredPlayers.map((player) => (
                          <TableRow key={player.id}>
                            <TableCell className="font-medium">{player.name}</TableCell>
                            <TableCell>{player.whatsappNumber}</TableCell>
                            <TableCell>{player.city}</TableCell>
                            <TableCell>{player.age}</TableCell>
                            <TableCell>
                              <div className="flex flex-wrap gap-1">
                                {player.events.map((event, index) => (
                                  <span
                                    key={index}
                                    className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-slate-100"
                                  >
                                    {event}
                                  </span>
                                ))}
                              </div>
                            </TableCell>
                            <TableCell>
                              <Button variant="ghost" size="sm" asChild>
                                <Link href={`/admin-dashboard/players/${player.id}`}>View Details</Link>
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-4 text-slate-500">
                            No players found
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
