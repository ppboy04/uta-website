"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CalendarIcon, LogOut, Save, User } from "lucide-react"

export default function PlayerDashboard() {
  // Mock player data - in a real app, this would come from an API
  const [playerData, setPlayerData] = useState({
    id: "p123",
    name: "Rahul Sharma",
    whatsappNumber: "9876543210",
    dob: "1985-06-15",
    city: "Dehradun",
    shirtSize: "l",
    shortSize: "m",
    foodPreference: "veg",
    stayRequired: "yes",
    feePaid: "yes",
    events: [
      {
        id: "a",
        name: "Category A (Open)",
        partner: {
          id: "p2",
          name: "Vikram Singh",
        },
      },
      {
        id: "c",
        name: "Category C (105+ combined)",
        partner: {
          id: "p5",
          name: "Rajesh Gupta",
        },
      },
    ],
  })

  const [isEditing, setIsEditing] = useState(false)
  const [formData, setFormData] = useState({
    name: playerData.name,
    whatsappNumber: playerData.whatsappNumber,
    dob: playerData.dob,
    city: playerData.city,
    shirtSize: playerData.shirtSize,
    shortSize: playerData.shortSize,
    foodPreference: playerData.foodPreference,
    stayRequired: playerData.stayRequired,
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSaveChanges = () => {
    // In a real app, you would send this to your API
    setPlayerData((prev) => ({
      ...prev,
      ...formData,
    }))
    setIsEditing(false)
  }

  // Mock data for events and players
  const events = [
    { id: "a", name: "Category A (Open)" },
    { id: "b", name: "Category B (90+ combined)" },
    { id: "c", name: "Category C (105+ combined)" },
    { id: "d", name: "Category D (120+ combined)" },
    { id: "lucky", name: "Lucky Doubles" },
  ]

  const players = [
    { id: "p1", name: "Rahul Sharma" },
    { id: "p2", name: "Vikram Singh" },
    { id: "p3", name: "Amit Patel" },
    { id: "p4", name: "Suresh Kumar" },
    { id: "p5", name: "Rajesh Gupta" },
    { id: "none", name: "Partner not registered yet" },
  ]

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/" className="flex items-center gap-3">
            <div>
              <h1 className="text-xl font-bold text-slate-800">UTA Tournament</h1>
              <p className="text-sm text-slate-500">Player Dashboard</p>
            </div>
          </Link>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="bg-slate-100 rounded-full p-1">
                <User className="h-5 w-5 text-slate-600" />
              </div>
              <span className="text-sm font-medium">{playerData.name}</span>
            </div>
            <Link href="/login">
              <Button variant="ghost" size="sm">
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Tabs defaultValue="profile">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="profile">My Profile</TabsTrigger>
              <TabsTrigger value="events">My Events</TabsTrigger>
            </TabsList>

            <TabsContent value="profile" className="mt-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>Personal Information</CardTitle>
                    <CardDescription>View and edit your personal details</CardDescription>
                  </div>
                  <Button
                    variant={isEditing ? "default" : "outline"}
                    onClick={() => (isEditing ? handleSaveChanges() : setIsEditing(true))}
                  >
                    {isEditing ? (
                      <>
                        <Save className="h-4 w-4 mr-2" />
                        Save Changes
                      </>
                    ) : (
                      "Edit Profile"
                    )}
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-6">
                    <div className="grid gap-3">
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        disabled={!isEditing}
                      />
                    </div>

                    <div className="grid gap-3">
                      <Label htmlFor="whatsappNumber">WhatsApp Number</Label>
                      <Input
                        id="whatsappNumber"
                        name="whatsappNumber"
                        value={formData.whatsappNumber}
                        onChange={handleInputChange}
                        disabled={!isEditing}
                      />
                    </div>

                    <div className="grid gap-3">
                      <Label htmlFor="dob">Date of Birth</Label>
                      <div className="relative">
                        <Input
                          id="dob"
                          name="dob"
                          type="date"
                          value={formData.dob}
                          onChange={handleInputChange}
                          disabled={!isEditing}
                        />
                        <CalendarIcon className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 pointer-events-none h-4 w-4" />
                      </div>
                    </div>

                    <div className="grid gap-3">
                      <Label htmlFor="city">City</Label>
                      <Input
                        id="city"
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        disabled={!isEditing}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="grid gap-3">
                        <Label htmlFor="shirtSize">T-Shirt Size</Label>
                        <Select
                          value={formData.shirtSize}
                          onValueChange={(value) => handleSelectChange("shirtSize", value)}
                          disabled={!isEditing}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select size" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="s">Small</SelectItem>
                            <SelectItem value="m">Medium</SelectItem>
                            <SelectItem value="l">Large</SelectItem>
                            <SelectItem value="xl">X-Large</SelectItem>
                            <SelectItem value="xxl">XX-Large</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="grid gap-3">
                        <Label htmlFor="shortSize">Shorts Size</Label>
                        <Select
                          value={formData.shortSize}
                          onValueChange={(value) => handleSelectChange("shortSize", value)}
                          disabled={!isEditing}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select size" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="s">Small</SelectItem>
                            <SelectItem value="m">Medium</SelectItem>
                            <SelectItem value="l">Large</SelectItem>
                            <SelectItem value="xl">X-Large</SelectItem>
                            <SelectItem value="xxl">XX-Large</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid gap-3">
                      <Label>Food Preference</Label>
                      <RadioGroup
                        value={formData.foodPreference}
                        onValueChange={(value) => handleSelectChange("foodPreference", value)}
                        className="flex gap-4"
                        disabled={!isEditing}
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="veg" id="veg" />
                          <Label htmlFor="veg" className="cursor-pointer">
                            Vegetarian
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="nonveg" id="nonveg" />
                          <Label htmlFor="nonveg" className="cursor-pointer">
                            Non-Vegetarian
                          </Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <div className="grid gap-3">
                      <Label>Stay Required</Label>
                      <RadioGroup
                        value={formData.stayRequired}
                        onValueChange={(value) => handleSelectChange("stayRequired", value)}
                        className="flex gap-4"
                        disabled={!isEditing}
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="yes" id="stay-yes" />
                          <Label htmlFor="stay-yes" className="cursor-pointer">
                            Yes
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="no" id="stay-no" />
                          <Label htmlFor="stay-no" className="cursor-pointer">
                            No
                          </Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <div className="grid gap-3">
                      <Label>Fee Status</Label>
                      <div
                        className={`inline-flex items-center px-3 py-1 rounded-full text-sm ${
                          playerData.feePaid === "yes" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"
                        }`}
                      >
                        {playerData.feePaid === "yes" ? "Paid" : "Pending"}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="events" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>My Events</CardTitle>
                  <CardDescription>View your registered events and partners</CardDescription>
                </CardHeader>
                <CardContent>
                  {playerData.events.length > 0 ? (
                    <div className="space-y-6">
                      {playerData.events.map((event, index) => (
                        <div key={event.id} className="border rounded-lg p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-semibold text-lg">{event.name}</h3>
                              <div className="mt-2 space-y-1">
                                <p className="text-sm text-slate-600">
                                  <span className="font-medium">Partner:</span> {event.partner.name}
                                </p>
                              </div>
                            </div>
                            <div className="bg-slate-100 px-3 py-1 rounded-full text-sm">Event {index + 1}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-slate-500">You haven't registered for any events yet.</p>
                      <Link href="/register" className="mt-4 inline-block">
                        <Button>Register for Events</Button>
                      </Link>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
