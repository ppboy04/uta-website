"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { LogOut, Save, Search, Trophy, User } from "lucide-react"

export default function AdminDashboard() {
  const [selectedEvent, setSelectedEvent] = useState("")
  const [searchQuery, setSearchQuery] = useState("")

  // Mock events data
  const events = [
    { id: "a", name: "Category A (Open)" },
    { id: "b", name: "Category B (90+ combined)" },
    { id: "c", name: "Category C (105+ combined)" },
    { id: "d", name: "Category D (120+ combined)" },
    { id: "lucky", name: "Lucky Doubles" },
  ]

  // Mock player pairs data
  const [playerPairs, setPlayerPairs] = useState([
    {
      id: "pair1",
      event: "a",
      player1: { id: "p1", name: "Rahul Sharma", age: 35 },
      player2: { id: "p2", name: "Vikram Singh", age: 38 },
      ranking: 1,
      combinedAge: 73,
    },
    {
      id: "pair2",
      event: "a",
      player1: { id: "p3", name: "Amit Patel", age: 32 },
      player2: { id: "p4", name: "Suresh Kumar", age: 36 },
      ranking: 2,
      combinedAge: 68,
    },
    {
      id: "pair3",
      event: "b",
      player1: { id: "p5", name: "Rajesh Gupta", age: 45 },
      player2: { id: "p6", name: "Mohan Lal", age: 48 },
      ranking: 1,
      combinedAge: 93,
    },
    {
      id: "pair4",
      event: "b",
      player1: { id: "p7", name: "Dinesh Sharma", age: 47 },
      player2: { id: "p8", name: "Prakash Jha", age: 46 },
      ranking: 2,
      combinedAge: 93,
    },
    {
      id: "pair5",
      event: "c",
      player1: { id: "p9", name: "Ramesh Verma", age: 52 },
      player2: { id: "p10", name: "Sunil Kapoor", age: 55 },
      ranking: 1,
      combinedAge: 107,
    },
  ])

  const handleRankingChange = (pairId: string, newRanking: number) => {
    setPlayerPairs((prev) => prev.map((pair) => (pair.id === pairId ? { ...pair, ranking: newRanking } : pair)))
  }

  const handleSaveRankings = () => {
    // In a real app, you would send this to your API
    console.log(
      "Saving rankings:",
      playerPairs.filter((pair) => pair.event === selectedEvent),
    )
    alert("Rankings saved successfully!")
  }

  const filteredPairs = playerPairs.filter((pair) => {
    if (selectedEvent && pair.event !== selectedEvent) return false

    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      return pair.player1.name.toLowerCase().includes(query) || pair.player2.name.toLowerCase().includes(query)
    }

    return true
  })

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/" className="flex items-center gap-3">
            <div>
              <h1 className="text-xl font-bold text-slate-800">UTA Tournament</h1>
              <p className="text-sm text-slate-500">Admin Dashboard</p>
            </div>
          </Link>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="bg-slate-100 rounded-full p-1">
                <User className="h-5 w-5 text-slate-600" />
              </div>
              <span className="text-sm font-medium">Admin</span>
            </div>
            <Link href="/login">
              <Button variant="ghost" size="sm">
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-2">
                <Trophy className="h-6 w-6 text-yellow-500" />
                Tournament Management
              </CardTitle>
              <CardDescription>Manage player pairs and rankings for each event</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6">
                <div className="flex flex-col md:flex-row gap-4 md:items-end">
                  <div className="grid gap-2 flex-1">
                    <Label htmlFor="event">Select Event</Label>
                    <Select value={selectedEvent} onValueChange={setSelectedEvent}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select an event" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Events</SelectItem>
                        {events.map((event) => (
                          <SelectItem key={event.id} value={event.id}>
                            {event.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid gap-2 flex-1">
                    <Label htmlFor="search">Search Players</Label>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                      <Input
                        id="search"
                        placeholder="Search by player name"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-9"
                      />
                    </div>
                  </div>

                  <Button onClick={handleSaveRankings} disabled={!selectedEvent}>
                    <Save className="h-4 w-4 mr-2" />
                    Save Rankings
                  </Button>
                </div>

                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Event</TableHead>
                        <TableHead>Player 1</TableHead>
                        <TableHead>Player 2</TableHead>
                        <TableHead>Combined Age</TableHead>
                        <TableHead>Ranking</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredPairs.length > 0 ? (
                        filteredPairs.map((pair) => (
                          <TableRow key={pair.id}>
                            <TableCell>{events.find((e) => e.id === pair.event)?.name}</TableCell>
                            <TableCell>
                              {pair.player1.name} ({pair.player1.age})
                            </TableCell>
                            <TableCell>
                              {pair.player2.name} ({pair.player2.age})
                            </TableCell>
                            <TableCell>{pair.combinedAge}</TableCell>
                            <TableCell>
                              <Select
                                value={pair.ranking.toString()}
                                onValueChange={(value) => handleRankingChange(pair.id, Number.parseInt(value))}
                              >
                                <SelectTrigger className="w-24">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {[1, 2, 3, 4, 5, 6, 7, 8].map((rank) => (
                                    <SelectItem key={rank} value={rank.toString()}>
                                      {rank}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center py-4 text-slate-500">
                            {selectedEvent ? "No pairs found for this event" : "Select an event to view pairs"}
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <p className="text-sm text-slate-500">Total Pairs: {filteredPairs.length}</p>
              <Button variant="outline" asChild>
                <Link href="/admin-dashboard/players">View All Players</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}
