"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { ArrowLeft, ArrowRight, CalendarIcon, CheckCircle } from "lucide-react"
import Link from "next/link"

export default function RegistrationForm() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    name: "",
    whatsappNumber: "",
    dob: "",
    city: "",
    shirtSize: "",
    shortSize: "",
    foodPreference: "veg",
    stayRequired: "no",
    feePaid: "no",
    event1: "",
    partner1: "",
    event2: "",
    partner2: "",
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleNext = () => {
    setStep(2)
    window.scrollTo(0, 0)
  }

  const handlePrevious = () => {
    setStep(1)
    window.scrollTo(0, 0)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      // In a real application, you would send this data to your backend API
      console.log("Form submitted:", formData)

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Redirect to success page
      router.push("/register/success")
    } catch (error) {
      console.error("Error submitting form:", error)
    }
  }

  // Mock data for events and players
  const events = [
    { id: "a", name: "Category A (Open)" },
    { id: "b", name: "Category B (90+ combined)" },
    { id: "c", name: "Category C (105+ combined)" },
    { id: "d", name: "Category D (120+ combined)" },
    { id: "lucky", name: "Lucky Doubles" },
  ]

  const players = [
    { id: "p1", name: "Rahul Sharma" },
    { id: "p2", name: "Vikram Singh" },
    { id: "p3", name: "Amit Patel" },
    { id: "p4", name: "Suresh Kumar" },
    { id: "p5", name: "Rajesh Gupta" },
    { id: "none", name: "Partner not registered yet" },
  ]

  return (
    <div className="min-h-screen bg-slate-50 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8">
            <Link href="/" className="text-slate-600 hover:text-slate-900 flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              <span>Back to Home</span>
            </Link>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Player Registration</CardTitle>
              <CardDescription>Register for the UTA Doubles Tournament 2024</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <div className={`flex items-center gap-2 ${step >= 1 ? "text-green-600" : "text-slate-400"}`}>
                    <div
                      className={`rounded-full w-8 h-8 flex items-center justify-center ${step >= 1 ? "bg-green-100" : "bg-slate-100"}`}
                    >
                      {step > 1 ? <CheckCircle className="h-5 w-5" /> : <span>1</span>}
                    </div>
                    <span>Personal Details</span>
                  </div>
                  <Separator className="flex-1 mx-4" />
                  <div className={`flex items-center gap-2 ${step >= 2 ? "text-green-600" : "text-slate-400"}`}>
                    <div
                      className={`rounded-full w-8 h-8 flex items-center justify-center ${step >= 2 ? "bg-green-100" : "bg-slate-100"}`}
                    >
                      <span>2</span>
                    </div>
                    <span>Event Selection</span>
                  </div>
                </div>
              </div>

              {step === 1 && (
                <form>
                  <div className="grid gap-6">
                    <div className="grid gap-3">
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        placeholder="Enter your full name"
                        required
                      />
                    </div>

                    <div className="grid gap-3">
                      <Label htmlFor="whatsappNumber">WhatsApp Number</Label>
                      <Input
                        id="whatsappNumber"
                        name="whatsappNumber"
                        value={formData.whatsappNumber}
                        onChange={handleInputChange}
                        placeholder="Enter your WhatsApp number"
                        required
                      />
                    </div>

                    <div className="grid gap-3">
                      <Label htmlFor="dob">Date of Birth</Label>
                      <div className="relative">
                        <Input
                          id="dob"
                          name="dob"
                          type="date"
                          value={formData.dob}
                          onChange={handleInputChange}
                          required
                        />
                        <CalendarIcon className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 pointer-events-none h-4 w-4" />
                      </div>
                    </div>

                    <div className="grid gap-3">
                      <Label htmlFor="city">City</Label>
                      <Input
                        id="city"
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        placeholder="Enter your city"
                        required
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="grid gap-3">
                        <Label htmlFor="shirtSize">T-Shirt Size</Label>
                        <Select
                          value={formData.shirtSize}
                          onValueChange={(value) => handleSelectChange("shirtSize", value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select size" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="s">Small</SelectItem>
                            <SelectItem value="m">Medium</SelectItem>
                            <SelectItem value="l">Large</SelectItem>
                            <SelectItem value="xl">X-Large</SelectItem>
                            <SelectItem value="xxl">XX-Large</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="grid gap-3">
                        <Label htmlFor="shortSize">Shorts Size</Label>
                        <Select
                          value={formData.shortSize}
                          onValueChange={(value) => handleSelectChange("shortSize", value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select size" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="s">Small</SelectItem>
                            <SelectItem value="m">Medium</SelectItem>
                            <SelectItem value="l">Large</SelectItem>
                            <SelectItem value="xl">X-Large</SelectItem>
                            <SelectItem value="xxl">XX-Large</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid gap-3">
                      <Label>Food Preference</Label>
                      <RadioGroup
                        value={formData.foodPreference}
                        onValueChange={(value) => handleSelectChange("foodPreference", value)}
                        className="flex gap-4"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="veg" id="veg" />
                          <Label htmlFor="veg" className="cursor-pointer">
                            Vegetarian
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="nonveg" id="nonveg" />
                          <Label htmlFor="nonveg" className="cursor-pointer">
                            Non-Vegetarian
                          </Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <div className="grid gap-3">
                      <Label>Stay Required</Label>
                      <RadioGroup
                        value={formData.stayRequired}
                        onValueChange={(value) => handleSelectChange("stayRequired", value)}
                        className="flex gap-4"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="yes" id="stay-yes" />
                          <Label htmlFor="stay-yes" className="cursor-pointer">
                            Yes
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="no" id="stay-no" />
                          <Label htmlFor="stay-no" className="cursor-pointer">
                            No
                          </Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <div className="grid gap-3">
                      <Label>Fee Paid</Label>
                      <RadioGroup
                        value={formData.feePaid}
                        onValueChange={(value) => handleSelectChange("feePaid", value)}
                        className="flex gap-4"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="yes" id="fee-yes" />
                          <Label htmlFor="fee-yes" className="cursor-pointer">
                            Yes
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="no" id="fee-no" />
                          <Label htmlFor="fee-no" className="cursor-pointer">
                            No
                          </Label>
                        </div>
                      </RadioGroup>
                    </div>
                  </div>
                </form>
              )}

              {step === 2 && (
                <form onSubmit={handleSubmit}>
                  <div className="grid gap-8">
                    <div className="grid gap-6">
                      <h3 className="text-lg font-semibold">Event 1</h3>

                      <div className="grid gap-3">
                        <Label htmlFor="event1">Select Event</Label>
                        <Select value={formData.event1} onValueChange={(value) => handleSelectChange("event1", value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select event" />
                          </SelectTrigger>
                          <SelectContent>
                            {events.map((event) => (
                              <SelectItem key={event.id} value={event.id}>
                                {event.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="grid gap-3">
                        <Label htmlFor="partner1">Select Partner</Label>
                        <Select
                          value={formData.partner1}
                          onValueChange={(value) => handleSelectChange("partner1", value)}
                          disabled={!formData.event1}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select partner" />
                          </SelectTrigger>
                          <SelectContent>
                            {players.map((player) => (
                              <SelectItem key={player.id} value={player.id}>
                                {player.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <Separator />

                    <div className="grid gap-6">
                      <div className="flex items-center justify-between">
                        <h3 className="text-lg font-semibold">Event 2 (Optional)</h3>
                        <p className="text-sm text-slate-500">You can register for up to 2 events</p>
                      </div>

                      <div className="grid gap-3">
                        <Label htmlFor="event2">Select Event</Label>
                        <Select value={formData.event2} onValueChange={(value) => handleSelectChange("event2", value)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select event" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">None</SelectItem>
                            {events.map((event) => (
                              <SelectItem key={event.id} value={event.id} disabled={event.id === formData.event1}>
                                {event.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="grid gap-3">
                        <Label htmlFor="partner2">Select Partner</Label>
                        <Select
                          value={formData.partner2}
                          onValueChange={(value) => handleSelectChange("partner2", value)}
                          disabled={!formData.event2}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select partner" />
                          </SelectTrigger>
                          <SelectContent>
                            {players.map((player) => (
                              <SelectItem key={player.id} value={player.id}>
                                {player.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </form>
              )}
            </CardContent>
            <CardFooter className="flex justify-between">
              {step === 1 ? (
                <>
                  <Link href="/">
                    <Button variant="outline">Cancel</Button>
                  </Link>
                  <Button onClick={handleNext}>
                    Next <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </>
              ) : (
                <>
                  <Button variant="outline" onClick={handlePrevious}>
                    <ArrowLeft className="mr-2 h-4 w-4" /> Previous
                  </Button>
                  <Button onClick={handleSubmit}>Submit Registration</Button>
                </>
              )}
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}
