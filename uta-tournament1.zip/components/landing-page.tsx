"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  CalendarIcon,
  MapPinIcon,
  TrophyIcon,
  UsersIcon,
  StarIcon,
  CheckCircleIcon,
  PhoneIcon,
  MailIcon,
  ClockIcon,
  AwardIcon,
  ShieldCheckIcon,
  HeartIcon,
} from "lucide-react"

export default function LandingPage() {
  const [activeTab, setActiveTab] = useState("about")

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white/95 backdrop-blur-sm shadow-lg border-b border-slate-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <div className="bg-gradient-to-br from-yellow-400 to-orange-500 p-2 rounded-xl shadow-lg">
              <TrophyIcon className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent">
                Uttaranchal Tennis Association
              </h1>
              <p className="text-sm text-slate-500 font-medium">Doubles Tournament 2024</p>
            </div>
          </div>
          <div className="flex gap-3">
            <Link href="/login">
              <Button variant="outline" className="border-slate-300 hover:bg-slate-50">
                Login
              </Button>
            </Link>
            <Link href="/register">
              <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-lg">
                Register Now
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-indigo-600/10"></div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="max-w-4xl mx-auto">
            <Badge className="mb-6 bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-4 py-2 text-sm font-semibold">
              🏆 Premium Tennis Tournament
            </Badge>
            <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-slate-800 via-blue-800 to-indigo-800 bg-clip-text text-transparent leading-tight">
              UTA Doubles Tournament
            </h2>
            <p className="text-xl md:text-2xl mb-8 text-slate-600 font-medium">
              December 8-9, 2024 • Shanti Tennis Academy, Dehradun
            </p>

            <div className="flex flex-wrap justify-center gap-6 mb-10">
              <div className="flex items-center gap-3 bg-white/80 backdrop-blur-sm px-6 py-3 rounded-full shadow-lg border border-white/50">
                <CalendarIcon className="h-5 w-5 text-blue-600" />
                <span className="font-semibold text-slate-700">Dec 8-9, 2024</span>
              </div>
              <div className="flex items-center gap-3 bg-white/80 backdrop-blur-sm px-6 py-3 rounded-full shadow-lg border border-white/50">
                <MapPinIcon className="h-5 w-5 text-green-600" />
                <span className="font-semibold text-slate-700">Shanti Tennis Academy</span>
              </div>
              <div className="flex items-center gap-3 bg-white/80 backdrop-blur-sm px-6 py-3 rounded-full shadow-lg border border-white/50">
                <UsersIcon className="h-5 w-5 text-purple-600" />
                <span className="font-semibold text-slate-700">5 Categories</span>
              </div>
              <div className="flex items-center gap-3 bg-white/80 backdrop-blur-sm px-6 py-3 rounded-full shadow-lg border border-white/50">
                <TrophyIcon className="h-5 w-5 text-yellow-600" />
                <span className="font-semibold text-slate-700">₹21,000 Prize</span>
              </div>
            </div>

            <div className="flex flex-wrap justify-center gap-4">
              <Link href="/register">
                <Button
                  size="lg"
                  className="text-lg px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-xl transform hover:scale-105 transition-all duration-200"
                >
                  🎾 Register Now
                </Button>
              </Link>
              <Link href="/login">
                <Button
                  size="lg"
                  variant="outline"
                  className="text-lg px-8 py-4 border-2 border-slate-300 hover:bg-slate-50 shadow-lg"
                >
                  Player Login
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white/50 backdrop-blur-sm">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="bg-gradient-to-br from-blue-500 to-blue-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <TrophyIcon className="h-8 w-8 text-white" />
              </div>
              <div className="text-3xl font-bold text-slate-800 mb-2">₹21K</div>
              <div className="text-sm text-slate-600 font-medium">Winner Prize</div>
            </div>
            <div className="text-center">
              <div className="bg-gradient-to-br from-green-500 to-green-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <UsersIcon className="h-8 w-8 text-white" />
              </div>
              <div className="text-3xl font-bold text-slate-800 mb-2">32</div>
              <div className="text-sm text-slate-600 font-medium">Teams per Category</div>
            </div>
            <div className="text-center">
              <div className="bg-gradient-to-br from-purple-500 to-purple-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <CalendarIcon className="h-8 w-8 text-white" />
              </div>
              <div className="text-3xl font-bold text-slate-800 mb-2">2</div>
              <div className="text-sm text-slate-600 font-medium">Days Tournament</div>
            </div>
            <div className="text-center">
              <div className="bg-gradient-to-br from-orange-500 to-orange-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <AwardIcon className="h-8 w-8 text-white" />
              </div>
              <div className="text-3xl font-bold text-slate-800 mb-2">5</div>
              <div className="text-sm text-slate-600 font-medium">Categories</div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <Tabs defaultValue="about" className="max-w-6xl mx-auto" onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-4 bg-white/80 backdrop-blur-sm shadow-lg border border-white/50">
              <TabsTrigger
                value="about"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white"
              >
                About
              </TabsTrigger>
              <TabsTrigger
                value="categories"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white"
              >
                Categories
              </TabsTrigger>
              <TabsTrigger
                value="rules"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white"
              >
                Rules
              </TabsTrigger>
              <TabsTrigger
                value="prizes"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white"
              >
                Prizes
              </TabsTrigger>
            </TabsList>

            <TabsContent
              value="about"
              className="p-8 bg-white/80 backdrop-blur-sm rounded-lg shadow-xl mt-6 border border-white/50"
            >
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div>
                  <h3 className="text-3xl font-bold mb-6 bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent">
                    About the Tournament
                  </h3>
                  <p className="mb-6 text-slate-600 leading-relaxed">
                    The Uttaranchal Tennis Association (UTA) is proud to host the annual Doubles Tournament, bringing
                    together tennis enthusiasts from across the region. This prestigious event features multiple
                    categories based on combined age groups, ensuring fair competition for all participants.
                  </p>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <CheckCircleIcon className="h-5 w-5 text-green-500" />
                      <span className="text-slate-700">Professional-grade facilities with 8 courts</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircleIcon className="h-5 w-5 text-green-500" />
                      <span className="text-slate-700">Premium kit worth over ₹3,000</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircleIcon className="h-5 w-5 text-green-500" />
                      <span className="text-slate-700">All meals and gala dinner included</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <CheckCircleIcon className="h-5 w-5 text-green-500" />
                      <span className="text-slate-700">Accommodation available</span>
                    </div>
                  </div>
                </div>
                <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-6 rounded-xl border border-blue-100">
                  <h4 className="text-xl font-semibold mb-4 text-slate-800">Tournament Highlights</h4>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="bg-blue-500 w-2 h-2 rounded-full"></div>
                      <span className="text-slate-700">Head Tour official balls</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="bg-blue-500 w-2 h-2 rounded-full"></div>
                      <span className="text-slate-700">Professional umpiring</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="bg-blue-500 w-2 h-2 rounded-full"></div>
                      <span className="text-slate-700">Live scoring updates</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="bg-blue-500 w-2 h-2 rounded-full"></div>
                      <span className="text-slate-700">Photography & videography</span>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent
              value="categories"
              className="p-8 bg-white/80 backdrop-blur-sm rounded-lg shadow-xl mt-6 border border-white/50"
            >
              <h3 className="text-3xl font-bold mb-8 text-center bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent">
                Tournament Categories
              </h3>
              <div className="grid gap-6">
                <Card className="border-l-4 border-l-blue-500 shadow-lg hover:shadow-xl transition-shadow">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2">
                      <StarIcon className="h-5 w-5 text-yellow-500" />
                      Category A (Open)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-600">
                      Open category for all eligible players. Coaches are only allowed in this category.
                    </p>
                  </CardContent>
                </Card>
                <Card className="border-l-4 border-l-green-500 shadow-lg hover:shadow-xl transition-shadow">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2">
                      <ShieldCheckIcon className="h-5 w-5 text-green-500" />
                      Category B (90+ combined)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-600">For pairs with a combined age of 90 years or more.</p>
                  </CardContent>
                </Card>
                <Card className="border-l-4 border-l-purple-500 shadow-lg hover:shadow-xl transition-shadow">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2">
                      <AwardIcon className="h-5 w-5 text-purple-500" />
                      Category C (105+ combined)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-600">For pairs with a combined age of 105 years or more.</p>
                  </CardContent>
                </Card>
                <Card className="border-l-4 border-l-orange-500 shadow-lg hover:shadow-xl transition-shadow">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2">
                      <TrophyIcon className="h-5 w-5 text-orange-500" />
                      Category D (120+ combined)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-600">For pairs with a combined age of 120 years or more.</p>
                  </CardContent>
                </Card>
                <Card className="border-l-4 border-l-pink-500 shadow-lg hover:shadow-xl transition-shadow">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2">
                      <HeartIcon className="h-5 w-5 text-pink-500" />
                      Lucky Doubles
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-600">
                      For players who lose both matches in round 1. Lottery pairing: One player &lt;=50 years paired
                      with one player &gt;50 years.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent
              value="rules"
              className="p-8 bg-white/80 backdrop-blur-sm rounded-lg shadow-xl mt-6 border border-white/50"
            >
              <h3 className="text-3xl font-bold mb-8 text-center bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent">
                Tournament Rules
              </h3>
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h4 className="text-xl font-semibold mb-4 text-slate-800">Eligibility & Registration</h4>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-3">
                      <CheckCircleIcon className="h-5 w-5 text-green-500 mt-0.5" />
                      <span className="text-slate-600">Minimum age: 30 years as of December 9, 2024</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircleIcon className="h-5 w-5 text-green-500 mt-0.5" />
                      <span className="text-slate-600">Maximum events: 2 categories + Lucky Doubles</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircleIcon className="h-5 w-5 text-green-500 mt-0.5" />
                      <span className="text-slate-600">Coaches only allowed in Category A</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <ClockIcon className="h-5 w-5 text-red-500 mt-0.5" />
                      <span className="text-slate-600">Entry deadline: December 7, 2024 (No exceptions)</span>
                    </li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-xl font-semibold mb-4 text-slate-800">Tournament Format</h4>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-3">
                      <CheckCircleIcon className="h-5 w-5 text-green-500 mt-0.5" />
                      <span className="text-slate-600">Draw size limit: 32 teams per category</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircleIcon className="h-5 w-5 text-green-500 mt-0.5" />
                      <span className="text-slate-600">Ball type: Head Tour</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircleIcon className="h-5 w-5 text-green-500 mt-0.5" />
                      <span className="text-slate-600">Walkovers given after 15 minutes</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircleIcon className="h-5 w-5 text-green-500 mt-0.5" />
                      <span className="text-slate-600">Draw release: December 8, 2024</span>
                    </li>
                  </ul>
                </div>
              </div>
            </TabsContent>

            <TabsContent
              value="prizes"
              className="p-8 bg-white/80 backdrop-blur-sm rounded-lg shadow-xl mt-6 border border-white/50"
            >
              <h3 className="text-3xl font-bold mb-8 text-center bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent">
                Prize Money
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse bg-white rounded-lg shadow-lg overflow-hidden">
                  <thead>
                    <tr className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white">
                      <th className="border-0 p-4 text-left font-semibold">Position</th>
                      <th className="border-0 p-4 text-left font-semibold">Regular Categories</th>
                      <th className="border-0 p-4 text-left font-semibold">Lucky Doubles</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="p-4 font-semibold text-slate-800">🏆 Winner</td>
                      <td className="p-4 text-green-600 font-bold text-lg">₹21,000</td>
                      <td className="p-4 text-green-600 font-bold">₹10,500</td>
                    </tr>
                    <tr className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="p-4 font-semibold text-slate-800">🥈 Runner-up</td>
                      <td className="p-4 text-blue-600 font-bold text-lg">₹11,000</td>
                      <td className="p-4 text-blue-600 font-bold">₹5,500</td>
                    </tr>
                    <tr className="hover:bg-slate-50">
                      <td className="p-4 font-semibold text-slate-800">🥉 Semifinalists</td>
                      <td className="p-4 text-orange-600 font-bold">₹4,000</td>
                      <td className="p-4 text-orange-600 font-bold">₹2,000</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Registration & Fees Section */}
      <section className="py-20 bg-gradient-to-br from-slate-100 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent">
                Registration & Fees
              </h2>
              <p className="text-xl text-slate-600">Choose your preferred package and join the tournament</p>
            </div>
            <div className="grid md:grid-cols-2 gap-8">
              <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm hover:shadow-2xl transition-shadow">
                <CardHeader className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-t-lg">
                  <CardTitle className="text-2xl">Registration Fees</CardTitle>
                  <CardDescription className="text-blue-100">Choose your preferred package</CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                      <span className="font-medium">1 event (without stay)</span>
                      <span className="font-bold text-lg text-green-600">₹3,000</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                      <span className="font-medium">1 event (with stay)</span>
                      <span className="font-bold text-lg text-green-600">₹4,500</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg border border-blue-200">
                      <span className="font-medium">2 events (without stay)</span>
                      <span className="font-bold text-lg text-blue-600">₹4,500</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg border border-blue-200">
                      <span className="font-medium">2 events (with stay)</span>
                      <span className="font-bold text-lg text-blue-600">₹6,000</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="bg-slate-50 rounded-b-lg">
                  <p className="text-sm text-slate-600">💡 Stay includes up to 2 days (double sharing)</p>
                </CardFooter>
              </Card>

              <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm hover:shadow-2xl transition-shadow">
                <CardHeader className="bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-t-lg">
                  <CardTitle className="text-2xl">What's Included</CardTitle>
                  <CardDescription className="text-green-100">Your registration package includes</CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="bg-green-100 p-1 rounded-full">
                        <CheckCircleIcon className="h-4 w-4 text-green-600" />
                      </div>
                      <span className="text-slate-700">Breakfast and lunch on both days</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="bg-green-100 p-1 rounded-full">
                        <CheckCircleIcon className="h-4 w-4 text-green-600" />
                      </div>
                      <span className="text-slate-700">Gala dinner on December 9th</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="bg-green-100 p-1 rounded-full">
                        <CheckCircleIcon className="h-4 w-4 text-green-600" />
                      </div>
                      <span className="text-slate-700">Premium kit (T-shirt, shorts, socks, cap, wristband)</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="bg-green-100 p-1 rounded-full">
                        <CheckCircleIcon className="h-4 w-4 text-green-600" />
                      </div>
                      <span className="text-slate-700">Access to professional-grade courts</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="bg-green-100 p-1 rounded-full">
                        <CheckCircleIcon className="h-4 w-4 text-green-600" />
                      </div>
                      <span className="text-slate-700">Official tournament Head Tour balls</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="bg-slate-50 rounded-b-lg">
                  <p className="text-sm text-slate-600">🎁 Kit value over ₹3,000</p>
                </CardFooter>
              </Card>
            </div>
            <div className="mt-12 text-center">
              <Link href="/register">
                <Button
                  size="lg"
                  className="text-xl px-12 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-xl transform hover:scale-105 transition-all duration-200"
                >
                  🎾 Register Now
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent">
                Contact Information
              </h2>
              <p className="text-xl text-slate-600">Get in touch with us for any queries</p>
            </div>
            <div className="grid md:grid-cols-2 gap-8">
              <Card className="shadow-xl border-0 bg-gradient-to-br from-blue-50 to-indigo-50 hover:shadow-2xl transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-2xl">
                    <PhoneIcon className="h-6 w-6 text-blue-600" />
                    Tournament Director
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <p className="font-bold text-xl text-slate-800">Sumit Goel</p>
                    <div className="flex items-center gap-2">
                      <PhoneIcon className="h-4 w-4 text-green-600" />
                      <span className="font-semibold text-green-600">9412977857</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MailIcon className="h-4 w-4 text-blue-600" />
                      <span className="text-slate-600">Available for all tournament queries</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-xl border-0 bg-gradient-to-br from-green-50 to-emerald-50 hover:shadow-2xl transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3 text-2xl">
                    <MapPinIcon className="h-6 w-6 text-green-600" />
                    Venues
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <p className="font-bold text-lg text-slate-800 mb-1">🎾 Tournament Venue</p>
                      <p className="text-slate-600">Shanti Tennis Academy, Dehradun</p>
                    </div>
                    <div>
                      <p className="font-bold text-lg text-slate-800 mb-1">🏨 Gala & Stay Venue</p>
                      <p className="text-slate-600">OM Farms, 8-A, Jogiwala, Badripur, Dehradun</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            <div className="mt-12 text-center">
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-8 rounded-xl border border-blue-100">
                <p className="text-lg text-slate-700 mb-4">📱 Join our WhatsApp group for live updates</p>
                <Button className="bg-green-500 hover:bg-green-600 text-white">Join WhatsApp Group</Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-slate-800 to-slate-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <div className="mb-6 md:mb-0 text-center md:text-left">
              <div className="flex items-center gap-3 justify-center md:justify-start mb-2">
                <div className="bg-gradient-to-br from-yellow-400 to-orange-500 p-2 rounded-lg">
                  <TrophyIcon className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold">Uttaranchal Tennis Association</h3>
              </div>
              <p className="text-slate-300 text-lg">Doubles Tournament 2024</p>
            </div>
            <div className="flex gap-6">
              <Link href="/register" className="text-white hover:text-yellow-400 transition-colors font-medium">
                Register
              </Link>
              <Link href="/login" className="text-white hover:text-yellow-400 transition-colors font-medium">
                Login
              </Link>
              <Link href="/admin-dashboard" className="text-white hover:text-yellow-400 transition-colors font-medium">
                Admin
              </Link>
            </div>
          </div>
          <div className="border-t border-slate-700 pt-8 text-center">
            <p className="text-slate-400">
              &copy; {new Date().getFullYear()} Uttaranchal Tennis Association. All rights reserved. |
              <span className="text-yellow-400"> Made with ❤️ for tennis enthusiasts</span>
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
